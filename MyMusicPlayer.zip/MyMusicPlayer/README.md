# Music — offline Android music player

Kotlin + Jetpack Compose + AndroidX Media3 (ExoPlayer + MediaSession). Plays songs from one
dedicated folder on the device. No internet permission, no accounts, no tracking.

## Where your music goes

```
Internal storage/Music/MyMusicPlayer/
```

The app creates this folder on first launch (reuses it if it already exists). Copy songs into it
with any file manager or from a PC over USB, then open the app; it rescans automatically each time
it comes to the foreground, and you can pull-to-refresh or tap **Rescan folder** at any time.
Sub-folders are included. The full path is shown in **Settings** with a **Copy path** button.

To change the folder, edit `app/src/main/java/com/mymusicplayer/MusicConfig.kt`
(`FOLDER_NAME`, `PARENT_DIRECTORY`, `INCLUDE_SUBFOLDERS`, `SUPPORTED_EXTENSIONS`).

## Why it is in shared storage (and not app-private storage)

Files in `Android/data/<package>/` are hidden from most file managers on Android 11+, so users
couldn't add songs. The folder therefore lives in the public `Music/` directory:

| Android | Creating the folder | Reading songs |
|---|---|---|
| 13+ | File API, no permission | `READ_MEDIA_AUDIO` + MediaStore |
| 11–12 | File API, no permission | `READ_EXTERNAL_STORAGE` + MediaStore |
| 10 | `requestLegacyExternalStorage` + `WRITE_EXTERNAL_STORAGE` | same |
| 7–9 | `WRITE_EXTERNAL_STORAGE` | same |

No `MANAGE_EXTERNAL_STORAGE`. `INTERNET` and `ACCESS_NETWORK_STATE` are explicitly removed in the
manifest (`tools:node="remove"`), so no merged library can add them back.

## Features

Core: play/pause/resume/stop, next/previous, seek bar plus 10-second skip, shuffle, repeat
(off/all/one), queue with "Play next", "Add to queue" and remove; title/artist/album/duration;
embedded album art with a generated placeholder; MP3, WAV, FLAC, AAC, M4A (plus OGG, OPUS).

Background: Media3 `MediaSessionService` with media notification, lock-screen controls,
headset and Bluetooth buttons, audio focus (pauses for calls, ducks for notifications), pause
on headphone unplug, wake lock while playing.

Offline extras: Home screen with recently played, favorites, most played and recently added;
search; sorting; albums and artists; sleep timer with a 10-second fade-out; playback speed;
resume where you left off (queue, position, shuffle, repeat restored after restart);
library stats; clear listening history. All stored locally with DataStore.

Robustness: corrupted or unreadable files are skipped automatically (with a message) and listed
in Settings; unsupported files in the folder are listed too; missing folder, blocked folder,
unmounted storage, denied permission and empty library each have their own screen or message.

UI: Material 3, custom light and dark palettes plus optional Material You colors, bottom
navigation on phones, navigation rail on tablets/foldables/landscape, two-pane Now Playing in
landscape.

## Build

Requirements: Android Studio Koala (2024.1) or newer, JDK 17, Android SDK 35.

Android Studio: **File › Open** this folder, let Gradle sync, then **Run**.

Command line:

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Release APK: **Build › Generate Signed App Bundle / APK › APK**, create or choose a keystore,
pick `release`. Or add a `signingConfigs` block to `app/build.gradle.kts` and run
`./gradlew assembleRelease`.

Sideloading on a phone: copy the APK over, open it, and allow "Install unknown apps" for your
file manager when prompted.

## Project layout

```
app/src/main/java/com/mymusicplayer/
  MusicConfig.kt            folder path + formats (edit here)
  MusicApp.kt               Application + tiny DI container, creates folder on first launch
  MainActivity.kt
  data/
    MusicFolderManager.kt   create/reuse folder, report problems
    MusicRepository.kt      list files → MediaScanner → MediaStore query (folder only)
    UserPrefs.kt            DataStore: theme, sort, favorites, history, play counts, last session
    Models.kt
  playback/
    PlaybackService.kt      ExoPlayer + MediaSession, audio focus, error skipping, session saving
    PlayerConnection.kt     MediaController wrapper → StateFlow for the UI, sleep timer
    MediaItems.kt
  ui/
    AppRoot.kt              permissions, navigation, adaptive bottom bar / rail
    MainViewModel.kt
    theme/  components/  screens/
```

## Testing checklist

1. Fresh install → folder appears in Files app under Music/MyMusicPlayer.
2. Empty folder → empty-library screen with the path and steps.
3. Copy a few songs, return to the app → they appear without tapping anything.
4. Play, lock the screen → controls on the lock screen; Bluetooth/headset buttons work.
5. Receive a call → music pauses and resumes after.
6. Drop a renamed `.txt` as `broken.mp3` → it's skipped with a message and listed in Settings.
7. Force-stop and reopen → the last queue and position are restored (paused).

## Design (v1.1)

Styled after Motorola's Hello UI on Android 15/16: wallpaper colors on by default, large
collapsing headers, grouped rounded settings cards, a cover-tinted Now Playing screen, a wavy
progress bar and a shape-morphing play button. The app is named "Music"; the folder name is
still set in `MusicConfig.kt`.
