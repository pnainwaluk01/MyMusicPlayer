# Default rules are sufficient; Media3 and Compose ship their own consumer rules.
