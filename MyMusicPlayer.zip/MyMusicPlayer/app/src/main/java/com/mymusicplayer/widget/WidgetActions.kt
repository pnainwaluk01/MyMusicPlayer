package com.mymusicplayer.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.action.ActionCallback
import androidx.media3.session.MediaController
import com.mymusicplayer.MusicApp
import com.mymusicplayer.data.Song
import com.mymusicplayer.playback.PlayerConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

val MixKey = ActionParameters.Key<String>("mix")
val SongKey = ActionParameters.Key<String>("songId")

object Mix {
    const val SHUFFLE = "shuffle"
    const val FAVORITES = "favorites"
    const val ADDED = "added"
    const val TOP = "top"
}

private suspend fun withPlayer(
    context: Context,
    block: suspend PlayerConnection.(MediaController, List<Song>) -> Unit,
) {
    val container = (context.applicationContext as MusicApp).container
    withContext(Dispatchers.Main) { container.player.runFromWidget(block) }
}

private fun PlayerConnection.shuffleLibrary(c: MediaController, songs: List<Song>) {
    if (songs.isNotEmpty()) playSongsNow(c, songs, songs.indices.random(), shuffle = true)
}

class PlayPauseAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) =
        withPlayer(context) { c, songs ->
            if (c.mediaItemCount == 0) shuffleLibrary(c, songs) else togglePlayPauseNow(c)
        }
}

class NextAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) =
        withPlayer(context) { c, songs ->
            if (c.mediaItemCount == 0) shuffleLibrary(c, songs) else { c.seekToNext(); c.play() }
        }
}

class PreviousAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) =
        withPlayer(context) { c, songs ->
            if (c.mediaItemCount == 0) shuffleLibrary(c, songs) else { c.seekToPrevious(); c.play() }
        }
}

class PlayMixAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val prefs = (context.applicationContext as MusicApp).container.prefs
        val mix = parameters[MixKey] ?: Mix.SHUFFLE
        withPlayer(context) { c, songs ->
            val byId = songs.associateBy { it.mediaId }
            val list = when (mix) {
                Mix.FAVORITES -> prefs.favorites.first().let { fav -> songs.filter { it.mediaId in fav } }
                Mix.ADDED -> songs.sortedByDescending { it.dateAddedSec }.take(50)
                Mix.TOP -> prefs.playCounts.first().entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.take(50)
                else -> emptyList()
            }
            if (list.isEmpty()) shuffleLibrary(c, songs)
            else playSongsNow(c, list, 0, shuffle = mix == Mix.FAVORITES)
        }
    }
}

/** Plays a song from the "recently played" row, continuing through that row. */
class PlaySongAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val prefs = (context.applicationContext as MusicApp).container.prefs
        val id = parameters[SongKey] ?: return
        withPlayer(context) { c, songs ->
            val byId = songs.associateBy { it.mediaId }
            val recent = prefs.recentlyPlayed.first().mapNotNull { byId[it] }
            val index = recent.indexOfFirst { it.mediaId == id }
            if (index >= 0) playSongsNow(c, recent, index)
            else shuffleLibrary(c, songs)
        }
    }
}
