package com.mymusicplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mymusicplayer.data.Song
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.SmartList
import com.mymusicplayer.ui.components.Artwork
import com.mymusicplayer.ui.components.EmptyLibrary
import com.mymusicplayer.util.formatTotalTime
import com.mymusicplayer.util.songCount
import java.util.Calendar

@Composable
fun HomeScreen(vm: MainViewModel, onOpenList: (SmartList) -> Unit, onOpenSongs: () -> Unit) {
    val lib by vm.library.collectAsStateWithLifecycle()
    val home by vm.home.collectAsStateWithLifecycle()

    when {
        !lib.hasScanned -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        lib.songs.isEmpty() -> Box(Modifier.statusBarsPadding()) {
            EmptyLibrary(vm.friendlyPath, vm.absolutePath, lib.folderStatus, lib.isScanning) { vm.scan(full = true) }
        }
        else -> LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val greeting = when (hour) { in 5..11 -> "Good morning"; in 12..17 -> "Good afternoon"; else -> "Good evening" }
                Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp)) {
                    Text(greeting, style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "${songCount(lib.songs.size)} on this device, ${formatTotalTime(lib.songs.sumOf { it.durationMs })} of music",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            item {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { vm.shuffle(lib.songs) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.size(8.dp)); Text("Shuffle all")
                    }
                    FilledTonalButton(onClick = onOpenSongs, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.size(8.dp)); Text("All songs")
                    }
                }
            }
            shelf(SmartList.RECENT, home.recentlyPlayed, vm, onOpenList)
            shelf(SmartList.FAVORITES, home.favorites, vm, onOpenList)
            shelf(SmartList.MOST, home.mostPlayed, vm, onOpenList)
            shelf(SmartList.ADDED, home.recentlyAdded, vm, onOpenList)
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.shelf(
    list: SmartList,
    songs: List<Song>,
    vm: MainViewModel,
    onOpen: (SmartList) -> Unit,
) {
    if (songs.isEmpty()) return
    item(key = list.route) {
        Column(Modifier.padding(top = 20.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(list.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { onOpen(list) }) { Text("See all") }
            }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                itemsIndexed(songs.take(15), key = { _, s -> s.id }) { index, song ->
                    Column(
                        Modifier.width(140.dp).clickable { vm.play(songs, index) },
                    ) {
                        Surface(shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp) {
                            Artwork(song, Modifier.size(140.dp), sizeHint = 140.dp, corner = 18.dp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(song.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            song.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
