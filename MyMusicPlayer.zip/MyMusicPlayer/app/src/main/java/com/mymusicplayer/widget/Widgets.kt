package com.mymusicplayer.widget

import android.content.Context
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.Action
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.material3.ColorProviders
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.mymusicplayer.MainActivity
import com.mymusicplayer.R
import com.mymusicplayer.ui.theme.DarkColors
import com.mymusicplayer.ui.theme.LightColors

// ---- receivers (registered in the manifest; Android lists these in the Widgets picker) ----

class NowPlayingWidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget: GlanceAppWidget = NowPlayingWidget() }
class CompactWidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget: GlanceAppWidget = CompactWidget() }
class CoverWidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget: GlanceAppWidget = CoverWidget() }
class MixesWidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget: GlanceAppWidget = MixesWidget() }

// ---- 1. Now playing 4×2 ----

class NowPlayingWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = WidgetSync.load(context, artPx = 300, recentCount = 4)
        provideContent {
            val data = liveData(context, initial, artPx = 300, recentCount = 4)
            WidgetTheme { NowPlayingContent(data) }
        }
    }
}

@Composable
private fun NowPlayingContent(data: WidgetData) {
    Column(
        GlanceModifier.fillMaxSize().appWidgetBackground().cornerRadius(28.dp)
            .background(GlanceTheme.colors.widgetBackground).padding(14.dp),
    ) {
        Row(GlanceModifier.fillMaxWidth().defaultWeight(), verticalAlignment = Alignment.CenterVertically) {
            ArtBox(data.current, 76.dp, 20.dp, GlanceModifier.clickable(actionStartActivity<MainActivity>()))
            Spacer(GlanceModifier.width(14.dp))
            Column(GlanceModifier.defaultWeight()) {
                SongText(data, titleSize = 16)
                Spacer(GlanceModifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconAction(R.drawable.ic_w_prev, "Previous", actionRunCallback<PreviousAction>())
                    Spacer(GlanceModifier.width(8.dp))
                    PlayButton(data.isPlaying, 48.dp)
                    Spacer(GlanceModifier.width(8.dp))
                    IconAction(R.drawable.ic_w_next, "Next", actionRunCallback<NextAction>())
                }
            }
        }
        if (data.recent.isNotEmpty()) {
            Spacer(GlanceModifier.height(10.dp))
            Row(GlanceModifier.fillMaxWidth()) {
                data.recent.forEachIndexed { i, song ->
                    if (i > 0) Spacer(GlanceModifier.width(8.dp))
                    Box(
                        GlanceModifier.defaultWeight().height(48.dp).cornerRadius(14.dp)
                            .clickable(actionRunCallback<PlaySongAction>(actionParametersOf(SongKey to song.id))),
                    ) {
                        ArtFill(song)
                    }
                }
            }
        }
    }
}

// ---- 2. Compact bar 4×1 ----

class CompactWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = WidgetSync.load(context, artPx = 144, recentCount = 0)
        provideContent {
            val data = liveData(context, initial, artPx = 144, recentCount = 0)
            WidgetTheme { CompactContent(data) }
        }
    }
}

@Composable
private fun CompactContent(data: WidgetData) {
    Row(
        GlanceModifier.fillMaxSize().appWidgetBackground().cornerRadius(40.dp)
            .background(GlanceTheme.colors.widgetBackground).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ArtBox(data.current, 44.dp, 22.dp, GlanceModifier.clickable(actionStartActivity<MainActivity>()))
        Column(GlanceModifier.defaultWeight().padding(horizontal = 10.dp).clickable(actionStartActivity<MainActivity>())) {
            SongText(data, titleSize = 14)
        }
        IconAction(R.drawable.ic_w_prev, "Previous", actionRunCallback<PreviousAction>())
        PlayButton(data.isPlaying, 40.dp, alwaysRound = true)
        IconAction(R.drawable.ic_w_next, "Next", actionRunCallback<NextAction>())
    }
}

// ---- 3. Cover 2×2 ----

class CoverWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val initial = WidgetSync.load(context, artPx = 400, recentCount = 0)
        provideContent {
            val data = liveData(context, initial, artPx = 400, recentCount = 0)
            WidgetTheme { CoverContent(data) }
        }
    }
}

@Composable
private fun CoverContent(data: WidgetData) {
    Box(
        GlanceModifier.fillMaxSize().appWidgetBackground().cornerRadius(28.dp)
            .background(GlanceTheme.colors.primaryContainer)
            .clickable(actionStartActivity<MainActivity>()),
    ) {
        ArtFill(data.current, big = true)
        Box(GlanceModifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.BottomCenter) {
            Row(
                GlanceModifier.fillMaxWidth().cornerRadius(22.dp).background(GlanceTheme.colors.widgetBackground)
                    .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    data.current?.title ?: "Shuffle all",
                    maxLines = 1,
                    style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Medium),
                    modifier = GlanceModifier.defaultWeight(),
                )
                PlayButton(data.isPlaying, 34.dp, alwaysRound = true)
            }
        }
    }
}

// ---- 4. Quick mixes 2×2 ----

class MixesWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { WidgetTheme { MixesContent() } }
    }
}

@Composable
private fun MixesContent() {
    val c = GlanceTheme.colors
    Column(
        GlanceModifier.fillMaxSize().appWidgetBackground().cornerRadius(28.dp)
            .background(c.widgetBackground).padding(10.dp),
    ) {
        Row(GlanceModifier.fillMaxWidth().defaultWeight()) {
            MixTile(R.drawable.ic_w_shuffle, "Shuffle", Mix.SHUFFLE, c.primaryContainer, c.onPrimaryContainer, GlanceModifier.defaultWeight())
            Spacer(GlanceModifier.width(8.dp))
            MixTile(R.drawable.ic_w_heart, "Favorites", Mix.FAVORITES, c.tertiaryContainer, c.onTertiaryContainer, GlanceModifier.defaultWeight())
        }
        Spacer(GlanceModifier.height(8.dp))
        Row(GlanceModifier.fillMaxWidth().defaultWeight()) {
            MixTile(R.drawable.ic_w_new, "New", Mix.ADDED, c.secondaryContainer, c.onSecondaryContainer, GlanceModifier.defaultWeight())
            Spacer(GlanceModifier.width(8.dp))
            MixTile(R.drawable.ic_w_top, "Top", Mix.TOP, c.surfaceVariant, c.onSurfaceVariant, GlanceModifier.defaultWeight())
        }
    }
}

@Composable
private fun MixTile(icon: Int, label: String, mix: String, bg: ColorProvider, fg: ColorProvider, modifier: GlanceModifier) {
    Column(
        modifier.fillMaxHeight().cornerRadius(20.dp).background(bg)
            .clickable(actionRunCallback<PlayMixAction>(actionParametersOf(MixKey to mix))),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(ImageProvider(icon), contentDescription = null, modifier = GlanceModifier.size(24.dp), colorFilter = ColorFilter.tint(fg))
        Spacer(GlanceModifier.height(4.dp))
        Text(label, maxLines = 1, style = TextStyle(color = fg, fontSize = 12.sp, fontWeight = FontWeight.Medium))
    }
}

// ---- shared pieces ----

/** Re-reads the snapshot every time WidgetSync.version changes, so an open session never goes stale. */
@Composable
private fun liveData(context: Context, initial: WidgetData, artPx: Int, recentCount: Int): WidgetData {
    val version by WidgetSync.version.collectAsState()
    val data by produceState(initial, version) {
        value = WidgetSync.load(context, artPx, recentCount)
    }
    return data
}

private val FallbackColors = ColorProviders(light = LightColors, dark = DarkColors)

@Composable
private fun WidgetTheme(content: @Composable () -> Unit) {
    // Wallpaper colours on Android 12+, like Moto's own widgets; app palette on older phones.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) GlanceTheme(content = content)
    else GlanceTheme(colors = FallbackColors, content = content)
}

@Composable
private fun SongText(data: WidgetData, titleSize: Int) {
    val song = data.current
    Text(
        song?.title ?: "Music",
        maxLines = 1,
        style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = titleSize.sp, fontWeight = FontWeight.Medium),
    )
    Text(
        song?.artist?.takeIf { it.isNotBlank() } ?: if (song == null) "Tap play to shuffle" else "Unknown artist",
        maxLines = 1,
        style = TextStyle(color = GlanceTheme.colors.onSurfaceVariant, fontSize = (titleSize - 2).sp),
    )
}

@Composable
private fun ArtBox(song: WidgetSong?, size: Dp, corner: Dp, modifier: GlanceModifier = GlanceModifier) {
    Box(modifier.size(size).cornerRadius(corner)) { ArtFill(song) }
}

@Composable
private fun ArtFill(song: WidgetSong?, big: Boolean = false) {
    val art = song?.art
    if (art != null) {
        Image(ImageProvider(art), contentDescription = null, modifier = GlanceModifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Box(GlanceModifier.fillMaxSize().background(GlanceTheme.colors.primaryContainer), contentAlignment = Alignment.Center) {
            Image(
                ImageProvider(R.drawable.ic_w_music), contentDescription = null,
                modifier = GlanceModifier.size(if (big) 56.dp else 22.dp),
                colorFilter = ColorFilter.tint(GlanceTheme.colors.onPrimaryContainer),
            )
        }
    }
}

@Composable
private fun PlayButton(playing: Boolean, size: Dp, alwaysRound: Boolean = false) {
    // Same idea as the app: rounded square when paused, circle when playing.
    val corner = if (playing || alwaysRound) size / 2 else size / 3
    Box(
        GlanceModifier.size(size).cornerRadius(corner).background(GlanceTheme.colors.primary)
            .clickable(actionRunCallback<PlayPauseAction>()),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            ImageProvider(if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play),
            contentDescription = if (playing) "Pause" else "Play",
            modifier = GlanceModifier.size(size / 2),
            colorFilter = ColorFilter.tint(GlanceTheme.colors.onPrimary),
        )
    }
}

@Composable
private fun IconAction(icon: Int, description: String, action: Action) {
    Box(
        GlanceModifier.size(40.dp).cornerRadius(20.dp).clickable(action),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            ImageProvider(icon), contentDescription = description,
            modifier = GlanceModifier.size(24.dp),
            colorFilter = ColorFilter.tint(GlanceTheme.colors.onSurface),
        )
    }
}
