package com.mymusicplayer.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.mymusicplayer.data.AppSettings
import com.mymusicplayer.data.ThemeMode

/*
 * "Night cassette" palette: deep ink indigo, a warm brass accent (like a tape-deck VU needle)
 * and a teal secondary. Light mode is cool paper rather than cream.
 */
private val Ink = Color(0xFF1B1F3B)
private val Brass = Color(0xFFF2A93B)
private val Teal = Color(0xFF2BB3A3)

private val LightColors = lightColorScheme(
    primary = Color(0xFF3A3F8F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE0FF),
    onPrimaryContainer = Ink,
    secondary = Color(0xFF9A5B00),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDDB3),
    onSecondaryContainer = Color(0xFF2E1800),
    tertiary = Color(0xFF00796B),
    tertiaryContainer = Color(0xFFB2F0E6),
    background = Color(0xFFF3F4FA),
    onBackground = Ink,
    surface = Color(0xFFF3F4FA),
    onSurface = Ink,
    surfaceVariant = Color(0xFFE1E2EE),
    onSurfaceVariant = Color(0xFF4A4C63),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFEDEEF6),
    surfaceContainer = Color(0xFFE8E9F3),
    surfaceContainerHigh = Color(0xFFE2E3EF),
    surfaceContainerHighest = Color(0xFFDCDDEA),
    outline = Color(0xFF7A7C94),
)

private val DarkColors = darkColorScheme(
    primary = Brass,
    onPrimary = Color(0xFF2E1A00),
    primaryContainer = Color(0xFF4A3410),
    onPrimaryContainer = Color(0xFFFFDDB3),
    secondary = Teal,
    onSecondary = Color(0xFF00201C),
    secondaryContainer = Color(0xFF0F3E39),
    onSecondaryContainer = Color(0xFFB2F0E6),
    tertiary = Color(0xFFB9BEFF),
    background = Color(0xFF0E1024),
    onBackground = Color(0xFFE5E6F5),
    surface = Color(0xFF0E1024),
    onSurface = Color(0xFFE5E6F5),
    surfaceVariant = Color(0xFF2A2D4A),
    onSurfaceVariant = Color(0xFFC2C4DC),
    surfaceContainerLowest = Color(0xFF090A1A),
    surfaceContainerLow = Color(0xFF14172E),
    surfaceContainer = Color(0xFF181B35),
    surfaceContainerHigh = Color(0xFF20233F),
    surfaceContainerHighest = Color(0xFF2A2D4A),
    outline = Color(0xFF8C8FAA),
)

private val AppTypography = Typography().run {
    copy(
        displaySmall = displaySmall.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp),
        headlineMedium = headlineMedium.copy(fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
        headlineSmall = headlineSmall.copy(fontWeight = FontWeight.Bold),
        titleLarge = titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = titleMedium.copy(fontWeight = FontWeight.SemiBold),
    )
}

@Composable
fun MusicTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val scheme = when {
        settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> DarkColors
        else -> LightColors
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = AppTypography, content = content)
}
