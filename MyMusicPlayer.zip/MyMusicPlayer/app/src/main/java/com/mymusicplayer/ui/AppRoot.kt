package com.mymusicplayer.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mymusicplayer.ui.components.MiniPlayer
import com.mymusicplayer.ui.screens.AlbumsScreen
import com.mymusicplayer.ui.screens.ArtistsScreen
import com.mymusicplayer.ui.screens.CollectionScreen
import com.mymusicplayer.ui.screens.HomeScreen
import com.mymusicplayer.ui.screens.NowPlayingScreen
import com.mymusicplayer.ui.screens.PermissionScreen
import com.mymusicplayer.ui.screens.SettingsScreen
import com.mymusicplayer.ui.screens.SongsScreen

object StoragePermissions {
    val audio: String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    /** Only what the folder approach needs: read audio (+ write on Android ≤10, + notifications on 13+). */
    val requested: Array<String> = buildList {
        add(audio)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    fun hasAudio(context: Context) =
        ContextCompat.checkSelfPermission(context, audio) == PackageManager.PERMISSION_GRANTED
}

object Routes {
    const val HOME = "home"
    const val SONGS = "songs"
    const val ALBUMS = "albums"
    const val ARTISTS = "artists"
    const val SETTINGS = "settings"
    const val NOW_PLAYING = "now_playing"
    const val ALBUM = "album/{id}"
    const val ARTIST = "artist/{name}"
    const val LIST = "list/{kind}"
}

private enum class TopLevel(val route: String, val label: String, val icon: ImageVector) {
    HOME(Routes.HOME, "Home", Icons.Rounded.Home),
    SONGS(Routes.SONGS, "Songs", Icons.Rounded.MusicNote),
    ALBUMS(Routes.ALBUMS, "Albums", Icons.Rounded.Album),
    ARTISTS(Routes.ARTISTS, "Artists", Icons.Rounded.Person),
    SETTINGS(Routes.SETTINGS, "Settings", Icons.Rounded.Settings),
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(StoragePermissions.hasAudio(context)) }
    var permanentlyDenied by rememberSaveable { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPermission = StoragePermissions.hasAudio(context)
        val activity = context as? Activity
        permanentlyDenied = !hasPermission && activity != null &&
            !ActivityCompat.shouldShowRequestPermissionRationale(activity, StoragePermissions.audio)
        if (hasPermission) vm.scan(full = true)
    }

    // Ask once automatically on first launch.
    LaunchedEffect(Unit) { if (!hasPermission) launcher.launch(StoragePermissions.requested) }

    // Quick incremental rescan whenever the app comes back (e.g. after copying files).
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        hasPermission = StoragePermissions.hasAudio(context)
        if (hasPermission) vm.scan(full = false)
    }

    if (!hasPermission) {
        PermissionScreen(
            friendlyPath = vm.friendlyPath,
            permanentlyDenied = permanentlyDenied,
            onRequest = { launcher.launch(StoragePermissions.requested) },
            onOpenSettings = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)),
                )
            },
        )
    } else {
        MainScaffold(vm)
    }
}

@Composable
private fun MainScaffold(vm: MainViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val playerState by vm.playerState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val showChrome = route != Routes.NOW_PLAYING
    val goTop: (String) -> Unit = { dest ->
        nav.navigate(dest) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    fun selected(item: TopLevel): Boolean = when (route) {
        null -> false
        Routes.ALBUM -> item == TopLevel.ALBUMS
        Routes.ARTIST -> item == TopLevel.ARTISTS
        Routes.LIST -> item == TopLevel.HOME
        else -> route == item.route
    }

    Row(Modifier.fillMaxSize()) {
        if (wide && showChrome) {
            NavigationRail {
                TopLevel.entries.forEach { item ->
                    NavigationRailItem(
                        selected = selected(item), onClick = { goTop(item.route) },
                        icon = { Icon(item.icon, null) }, label = { Text(item.label) },
                    )
                }
            }
        }
        Scaffold(
            modifier = Modifier.weight(1f),
            contentWindowInsets = WindowInsets(0),
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (showChrome) {
                    Column(if (wide) Modifier.navigationBarsPadding() else Modifier) {
                        MiniPlayer(
                            state = playerState,
                            onOpen = { nav.navigate(Routes.NOW_PLAYING) { launchSingleTop = true } },
                            onPlayPause = vm::togglePlayPause,
                            onNext = vm::next,
                        )
                        if (!wide) {
                            NavigationBar {
                                TopLevel.entries.forEach { item ->
                                    NavigationBarItem(
                                        selected = selected(item), onClick = { goTop(item.route) },
                                        icon = { Icon(item.icon, null) }, label = { Text(item.label) },
                                    )
                                }
                            }
                        }
                    }
                }
            },
        ) { padding ->
            AppNavHost(nav, vm, Modifier.padding(padding))
        }
    }
}

@Composable
private fun AppNavHost(nav: NavHostController, vm: MainViewModel, modifier: Modifier) {
    NavHost(nav, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) {
            HomeScreen(
                vm,
                onOpenList = { nav.navigate("list/${it.route}") },
                onOpenSongs = { nav.navigate(Routes.SONGS) { launchSingleTop = true } },
            )
        }
        composable(Routes.SONGS) { SongsScreen(vm) }
        composable(Routes.ALBUMS) { AlbumsScreen(vm, onAlbum = { nav.navigate("album/${it.id}") }) }
        composable(Routes.ARTISTS) { ArtistsScreen(vm, onArtist = { nav.navigate("artist/${Uri.encode(it.name)}") }) }
        composable(Routes.SETTINGS) { SettingsScreen(vm) }

        composable(Routes.ALBUM, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
            val id = entry.arguments?.getLong("id")
            val albums by vm.albums.collectAsStateWithLifecycle()
            val album = albums.firstOrNull { it.id == id }
            CollectionScreen(
                vm = vm, title = album?.title ?: "Album",
                subtitle = album?.artist, songs = album?.songs.orEmpty(), cover = album?.cover,
                emptyHint = "This album is no longer in your folder.", onBack = { nav.popBackStack() },
            )
        }
        composable(Routes.ARTIST) { entry ->
            val name = entry.arguments?.getString("name").orEmpty()
            val artists by vm.artists.collectAsStateWithLifecycle()
            val artist = artists.firstOrNull { it.name == name }
            CollectionScreen(
                vm = vm, title = name, subtitle = artist?.let { if (it.albumCount == 1) "1 album" else "${it.albumCount} albums" },
                songs = artist?.songs.orEmpty(), cover = artist?.songs?.firstOrNull(),
                emptyHint = "No songs by this artist right now.", onBack = { nav.popBackStack() },
            )
        }
        composable(Routes.LIST) { entry ->
            val kind = SmartList.entries.firstOrNull { it.route == entry.arguments?.getString("kind") } ?: SmartList.FAVORITES
            val home by vm.home.collectAsStateWithLifecycle()
            val songs = vm.smartList(home, kind)
            CollectionScreen(
                vm = vm, title = kind.title, subtitle = null, songs = songs, cover = songs.firstOrNull(),
                emptyHint = kind.emptyHint, onBack = { nav.popBackStack() },
            )
        }
        composable(
            Routes.NOW_PLAYING,
            enterTransition = { slideInVertically { it } },
            exitTransition = { slideOutVertically { it } },
            popEnterTransition = { slideInVertically { it } },
            popExitTransition = { slideOutVertically { it } },
        ) {
            NowPlayingScreen(vm, onClose = { nav.popBackStack() })
        }
    }
}
