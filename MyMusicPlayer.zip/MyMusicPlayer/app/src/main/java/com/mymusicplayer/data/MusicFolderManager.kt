package com.mymusicplayer.data

import android.os.Environment
import com.mymusicplayer.MusicConfig
import java.io.File

/**
 * Creates and locates the dedicated folder in shared storage.
 *
 * Why this works under scoped storage:
 *  - Android 11+: apps may create directories inside standard public dirs (Music/) via File APIs.
 *  - Android 10: `requestLegacyExternalStorage` + WRITE_EXTERNAL_STORAGE (maxSdk 29).
 *  - Android 9 and lower: WRITE_EXTERNAL_STORAGE.
 * Reading songs the user copied there goes through MediaStore (READ_MEDIA_AUDIO / READ_EXTERNAL_STORAGE).
 */
class MusicFolderManager {

    @Suppress("DEPRECATION")
    val folder: File
        get() = File(Environment.getExternalStoragePublicDirectory(MusicConfig.PARENT_DIRECTORY), MusicConfig.FOLDER_NAME)

    val friendlyPath: String
        get() = "Internal storage › ${MusicConfig.PARENT_DIRECTORY} › ${MusicConfig.FOLDER_NAME}"

    val absolutePath: String get() = folder.absolutePath

    fun ensureFolder(): FolderStatus {
        if (Environment.getExternalStorageState() != Environment.MEDIA_MOUNTED) {
            return FolderStatus.Unavailable("Shared storage isn't available right now. Unlock the device or disconnect USB storage mode.")
        }
        val dir = folder
        return try {
            when {
                dir.isDirectory -> FolderStatus.Ready(createdNow = false) // reuse, never duplicate
                dir.exists() -> FolderStatus.Unavailable("A file named “${dir.name}” is in the way. Rename or delete it, then rescan.")
                dir.mkdirs() -> FolderStatus.Ready(createdNow = true)
                else -> FolderStatus.Unavailable("The folder couldn't be created automatically. Create “${MusicConfig.RELATIVE_PATH}” in your file manager, then rescan.")
            }
        } catch (e: SecurityException) {
            FolderStatus.Unavailable("Storage access is needed to create the folder. Allow it in app settings.")
        }
    }
}
