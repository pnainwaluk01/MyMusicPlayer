package com.mymusicplayer.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.mymusicplayer.AppContainer
import com.mymusicplayer.MusicApp
import com.mymusicplayer.data.Album
import com.mymusicplayer.data.AppSettings
import com.mymusicplayer.data.Artist
import com.mymusicplayer.data.LibraryState
import com.mymusicplayer.data.Song
import com.mymusicplayer.data.SortOrder
import com.mymusicplayer.data.ThemeMode
import com.mymusicplayer.data.applySort
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeData(
    val recentlyPlayed: List<Song> = emptyList(),
    val mostPlayed: List<Song> = emptyList(),
    val favorites: List<Song> = emptyList(),
    val recentlyAdded: List<Song> = emptyList(),
)

enum class SmartList(val route: String, val title: String, val emptyHint: String) {
    FAVORITES("favorites", "Favorites", "Tap the heart on any song to keep it here."),
    RECENT("recent", "Recently played", "Songs you play show up here."),
    MOST("most", "Most played", "Your top songs appear after a few listens."),
    ADDED("added", "Recently added", "New files in your music folder appear here."),
}

class MainViewModel(private val c: AppContainer) : ViewModel() {

    val library: StateFlow<LibraryState> = c.repository.library
    val playerState = c.player.state
    val sleepTimerEndsAt = c.player.sleepTimerEndsAt
    val messages = c.player.messages
    val friendlyPath: String = c.folderManager.friendlyPath
    val absolutePath: String = c.folderManager.absolutePath

    val settings: StateFlow<AppSettings> =
        c.prefs.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val favorites: StateFlow<Set<String>> =
        c.prefs.favorites.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val songs: StateFlow<List<Song>> = combine(library, settings, _query) { lib, s, q ->
        val sorted = lib.songs.applySort(s.sort)
        if (q.isBlank()) sorted else {
            val needle = q.trim()
            sorted.filter {
                it.title.contains(needle, true) || it.artist.contains(needle, true) || it.album.contains(needle, true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val albums: StateFlow<List<Album>> = library.map { lib ->
        lib.songs.groupBy { it.albumId }.map { (id, list) ->
            val artists = list.map { it.artist }.distinct()
            Album(
                id = id,
                title = list.first().album,
                artist = if (artists.size == 1) artists.first() else "Various artists",
                songs = list.sortedWith(compareBy({ it.track }, { it.title.lowercase() })),
            )
        }.sortedBy { it.title.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val artists: StateFlow<List<Artist>> = library.map { lib ->
        lib.songs.groupBy { it.artist }.map { (name, list) ->
            Artist(name, list.applySort(SortOrder.ALBUM), list.map { it.albumId }.distinct().size)
        }.sortedBy { it.name.lowercase() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val home: StateFlow<HomeData> = combine(
        library, favorites, c.prefs.recentlyPlayed, c.prefs.playCounts,
    ) { lib, fav, recent, counts ->
        val byId = lib.songs.associateBy { it.mediaId }
        HomeData(
            recentlyPlayed = recent.mapNotNull { byId[it] },
            mostPlayed = counts.entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.take(50),
            favorites = lib.songs.filter { it.mediaId in fav }.applySort(SortOrder.TITLE),
            recentlyAdded = lib.songs.applySort(SortOrder.DATE_ADDED).take(50),
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HomeData())

    fun smartList(home: HomeData, list: SmartList): List<Song> = when (list) {
        SmartList.FAVORITES -> home.favorites
        SmartList.RECENT -> home.recentlyPlayed
        SmartList.MOST -> home.mostPlayed
        SmartList.ADDED -> home.recentlyAdded
    }

    // ---- library ---------------------------------------------------------------------------

    fun scan(full: Boolean) = viewModelScope.launch {
        val state = c.repository.scan(full)
        if (full) com.mymusicplayer.ui.components.ArtworkLoader.clear()
        if (state.songs.isNotEmpty()) c.player.restoreLastSession()
        if (full) {
            val n = state.songs.size
            c.player.notify(if (n == 0) "No songs found in the folder" else "Found ${if (n == 1) "1 song" else "$n songs"}")
        }
    }

    fun setQuery(q: String) { _query.value = q }
    fun setSort(order: SortOrder) = viewModelScope.launch { c.prefs.setSort(order) }
    fun setTheme(mode: ThemeMode) = viewModelScope.launch { c.prefs.setTheme(mode) }
    fun setDynamicColor(on: Boolean) = viewModelScope.launch { c.prefs.setDynamicColor(on) }
    fun clearHistory() = viewModelScope.launch {
        c.prefs.clearHistory(); c.player.notify("Listening history cleared")
    }
    fun toggleFavorite(song: Song) = viewModelScope.launch { c.prefs.toggleFavorite(song.mediaId) }

    // ---- playback --------------------------------------------------------------------------

    fun play(songs: List<Song>, index: Int) = c.player.playSongs(songs, index)
    fun shuffle(songs: List<Song>) = c.player.shuffleAll(songs)
    fun playNext(song: Song) = c.player.playNext(song)
    fun addToQueue(song: Song) = c.player.addToQueue(song)
    fun togglePlayPause() = c.player.togglePlayPause()
    fun stop() = c.player.stop()
    fun next() = c.player.next()
    fun previous() = c.player.previous()
    fun seekTo(ms: Long) = c.player.seekTo(ms)
    fun seekBack() = c.player.seekBack()
    fun seekForward() = c.player.seekForward()
    fun toggleShuffle() = c.player.toggleShuffle()
    fun cycleRepeat() = c.player.cycleRepeat()
    fun setSpeed(s: Float) = c.player.setSpeed(s)
    fun setSleepTimer(minutes: Int?) = c.player.setSleepTimer(minutes)
    fun playQueueIndex(i: Int) = c.player.playQueueIndex(i)
    fun removeFromQueue(i: Int) = c.player.removeFromQueue(i)

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as MusicApp
                MainViewModel(app.container)
            }
        }
    }
}
