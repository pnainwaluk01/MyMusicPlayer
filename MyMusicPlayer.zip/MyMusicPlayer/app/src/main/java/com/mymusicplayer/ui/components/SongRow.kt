package com.mymusicplayer.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mymusicplayer.data.Song
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.util.formatDuration

@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var menu by remember { mutableStateOf(false) }
    val accent = MaterialTheme.colorScheme.primary
    ListItem(
        modifier = modifier.clickable(onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        headlineContent = {
            Text(
                song.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) accent else Color.Unspecified,
                fontWeight = if (isCurrent) FontWeight.Bold else null,
            )
        },
        supportingContent = {
            Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        leadingContent = {
            Box(Modifier.size(52.dp)) {
                Artwork(song, Modifier.matchParentSize(), sizeHint = 52.dp, corner = 16.dp)
                if (isCurrent) {
                    Box(
                        Modifier.matchParentSize().clip(RoundedCornerShape(16.dp))
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isPlaying) EqualizerBars()
                        else Icon(Icons.Rounded.Pause, contentDescription = "Paused", tint = Color.White)
                    }
                }
            }
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    formatDuration(song.durationMs),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "More options for ${song.title}")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Play next") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Rounded.PlaylistPlay, null) },
                            onClick = { menu = false; onPlayNext() },
                        )
                        DropdownMenuItem(
                            text = { Text("Add to queue") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null) },
                            onClick = { menu = false; onAddToQueue() },
                        )
                        DropdownMenuItem(
                            text = { Text(if (isFavorite) "Remove from favorites" else "Add to favorites") },
                            leadingIcon = {
                                Icon(if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null)
                            },
                            onClick = { menu = false; onToggleFavorite() },
                        )
                    }
                }
            }
        },
    )
}

/** Shared list rendering so every screen behaves the same way. */
fun LazyListScope.songItems(
    songs: List<Song>,
    currentId: String?,
    isPlaying: Boolean,
    favorites: Set<String>,
    vm: MainViewModel,
) {
    itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
        SongRow(
            song = song,
            isCurrent = song.mediaId == currentId,
            isPlaying = isPlaying,
            isFavorite = song.mediaId in favorites,
            onClick = { vm.play(songs, index) },
            onPlayNext = { vm.playNext(song) },
            onAddToQueue = { vm.addToQueue(song) },
            onToggleFavorite = { vm.toggleFavorite(song) },
            modifier = Modifier.animateItem(),
        )
    }
}

@Composable
fun EqualizerBars(modifier: Modifier = Modifier, color: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "eq")
    val heights = listOf(0, 160, 320).map { offset ->
        t.animateFloat(
            initialValue = 0.25f, targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(480, easing = LinearEasing), RepeatMode.Reverse, StartOffset(offset),
            ),
            label = "bar$offset",
        )
    }
    Row(
        modifier.size(18.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        heights.forEach { h ->
            Box(Modifier.weight(1f).fillMaxHeight(h.value).clip(RoundedCornerShape(1.dp)).background(color))
        }
    }
}
