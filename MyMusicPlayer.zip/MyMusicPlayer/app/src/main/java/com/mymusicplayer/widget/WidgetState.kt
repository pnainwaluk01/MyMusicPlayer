package com.mymusicplayer.widget

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.glance.appwidget.updateAll
import androidx.media3.common.Player
import com.mymusicplayer.MusicApp
import com.mymusicplayer.data.Song
import com.mymusicplayer.ui.components.ArtworkLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class WidgetSong(val id: String, val title: String, val artist: String, val art: Bitmap?)

data class WidgetData(val current: WidgetSong?, val isPlaying: Boolean, val recent: List<WidgetSong>)

/**
 * Keeps a tiny snapshot of "what's playing" for the home-screen widgets, written by the
 * playback service and read whenever a widget redraws (even if the app process restarted).
 */
object WidgetSync {
    private const val PREFS = "widget_state"
    private var lastKey: String? = null

    fun onPlayerChanged(context: Context, player: Player, scope: CoroutineScope) {
        val item = player.currentMediaItem
        val playing = player.playWhenReady &&
            player.playbackState != Player.STATE_IDLE &&
            player.playbackState != Player.STATE_ENDED
        val title = item?.mediaMetadata?.title?.toString()
        val key = "${item?.mediaId}|$playing|$title"
        if (key == lastKey) return
        lastKey = key
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("id", item?.mediaId)
            .putString("title", title)
            .putString("artist", item?.mediaMetadata?.artist?.toString())
            .putBoolean("playing", playing)
            .apply()
        scope.launch {
            delay(400) // let "recently played" be saved first
            updatePlayerWidgets(context)
        }
    }

    fun markStopped(context: Context, scope: CoroutineScope) {
        lastKey = null
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("playing", false).apply()
        scope.launch { updatePlayerWidgets(context) }
    }

    suspend fun updatePlayerWidgets(context: Context) {
        runCatching {
            NowPlayingWidget().updateAll(context)
            CompactWidget().updateAll(context)
            CoverWidget().updateAll(context)
        }
    }

    suspend fun load(context: Context, artPx: Int, recentCount: Int): WidgetData {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getString("id", null)
        val current = id?.let {
            WidgetSong(it, p.getString("title", null) ?: "Unknown title", p.getString("artist", null).orEmpty(), art(context, it, artPx))
        }
        val recent = if (recentCount <= 0) emptyList() else {
            val prefs = (context.applicationContext as MusicApp).container.prefs
            prefs.recentlyPlayed.first().filter { it != id }.take(recentCount)
                .map { WidgetSong(it, "", "", art(context, it, 144)) }
        }
        return WidgetData(current, p.getBoolean("playing", false) && current != null, recent)
    }

    private suspend fun art(context: Context, id: String, px: Int): Bitmap? {
        val longId = id.toLongOrNull() ?: return null
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, longId)
        val song = Song.placeholder(id, null, null, null).copy(uri = uri)
        val bmp = runCatching { ArtworkLoader.load(context, song, px)?.asAndroidBitmap() }.getOrNull() ?: return null
        // Widgets can't draw hardware bitmaps.
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            bmp.copy(Bitmap.Config.ARGB_8888, false)
        } else bmp
    }
}
