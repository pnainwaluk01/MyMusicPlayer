package com.mymusicplayer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mymusicplayer.data.Song
import com.mymusicplayer.data.SortOrder
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.components.EmptyLibrary
import com.mymusicplayer.ui.components.songItems
import com.mymusicplayer.util.formatTotalTime
import com.mymusicplayer.util.songCount

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongsScreen(vm: MainViewModel) {
    val lib by vm.library.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val player by vm.playerState.collectAsStateWithLifecycle()
    var searching by rememberSaveable { mutableStateOf(query.isNotEmpty()) }
    var sortMenu by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                if (searching) SearchField(query, vm::setQuery)
                else Text("Songs")
            },
            actions = {
                if (searching) {
                    IconButton(onClick = { searching = false; vm.setQuery("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close search")
                    }
                } else {
                    IconButton(onClick = { searching = true }) { Icon(Icons.Rounded.Search, contentDescription = "Search") }
                }
                Box {
                    IconButton(onClick = { sortMenu = true }) { Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = "Sort") }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        SortOrder.entries.forEach { order ->
                            DropdownMenuItem(
                                text = { Text(order.label) },
                                onClick = { vm.setSort(order); sortMenu = false },
                                trailingIcon = { if (order == settings.sort) Icon(Icons.Rounded.Check, null) },
                            )
                        }
                    }
                }
                IconButton(onClick = { vm.scan(full = true) }, enabled = !lib.isScanning) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Rescan folder")
                }
            },
        )

        when {
            !lib.hasScanned -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            lib.songs.isEmpty() -> EmptyLibrary(vm.friendlyPath, vm.absolutePath, lib.folderStatus, lib.isScanning) { vm.scan(full = true) }
            else -> PullToRefreshBox(
                isRefreshing = lib.isScanning,
                onRefresh = { vm.scan(full = true) },
                modifier = Modifier.fillMaxSize(),
            ) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                    item(key = "header") { PlayHeader(songs, onPlay = { vm.play(songs, 0) }, onShuffle = { vm.shuffle(songs) }) }
                    if (songs.isEmpty()) {
                        item(key = "nomatch") {
                            Text(
                                "No songs match “$query”. Try a title, artist or album name.",
                                Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    songItems(songs, player.currentSong?.mediaId, player.isPlaying, favorites, vm)
                }
            }
        }
    }
}

@Composable
fun PlayHeader(songs: List<Song>, onPlay: () -> Unit, onShuffle: () -> Unit) {
    if (songs.isEmpty()) return
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(
            "${songCount(songs.size)}, ${formatTotalTime(songs.sumOf { it.durationMs })}",
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onPlay, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.size(8.dp)); Text("Play")
            }
            FilledTonalButton(onClick = onShuffle, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.size(8.dp)); Text("Shuffle")
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    TextField(
        value = query,
        onValueChange = onChange,
        placeholder = { Text("Search songs, artists, albums") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().focusRequester(focus),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
        ),
    )
}
