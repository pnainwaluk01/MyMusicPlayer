package com.mymusicplayer

import android.media.AudioManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.getValue
import com.mymusicplayer.ui.AppRoot
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.theme.MusicTheme

class MainActivity : ComponentActivity() {
    private val container get() = (application as MusicApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC
        setContent {
            val vm: MainViewModel = viewModel(factory = MainViewModel.Factory)
            val settings by vm.settings.collectAsStateWithLifecycle()
            MusicTheme(settings) { AppRoot(vm) }
        }
    }

    override fun onStart() {
        super.onStart()
        container.player.attachUi()
    }

    override fun onStop() {
        container.player.detachUi()
        super.onStop()
    }
}
