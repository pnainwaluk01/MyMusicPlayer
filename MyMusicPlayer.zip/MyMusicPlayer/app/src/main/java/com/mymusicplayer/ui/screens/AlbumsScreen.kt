package com.mymusicplayer.ui.screens

import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mymusicplayer.data.Album
import com.mymusicplayer.data.Artist
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.components.Artwork
import com.mymusicplayer.ui.components.EmptyLibrary
import com.mymusicplayer.util.songCount

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumsScreen(vm: MainViewModel, onAlbum: (Album) -> Unit) {
    val albums by vm.albums.collectAsStateWithLifecycle()
    val lib by vm.library.collectAsStateWithLifecycle()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Column(Modifier.fillMaxSize().nestedScroll(scroll.nestedScrollConnection)) {
        LargeTopAppBar(title = { Text("Albums") }, scrollBehavior = scroll)
        if (lib.hasScanned && albums.isEmpty()) {
            EmptyLibrary(vm.friendlyPath, vm.absolutePath, lib.folderStatus, lib.isScanning) { vm.scan(true) }
            return@Column
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(albums, key = { it.id }) { album ->
                Column(Modifier.clickable { onAlbum(album) }) {
                    Artwork(album.cover, Modifier.fillMaxWidth().aspectRatio(1f), sizeHint = 240.dp, corner = 28.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(album.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        album.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistsScreen(vm: MainViewModel, onArtist: (Artist) -> Unit) {
    val artists by vm.artists.collectAsStateWithLifecycle()
    val lib by vm.library.collectAsStateWithLifecycle()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Column(Modifier.fillMaxSize().nestedScroll(scroll.nestedScrollConnection)) {
        LargeTopAppBar(title = { Text("Artists") }, scrollBehavior = scroll)
        if (lib.hasScanned && artists.isEmpty()) {
            EmptyLibrary(vm.friendlyPath, vm.absolutePath, lib.folderStatus, lib.isScanning) { vm.scan(true) }
            return@Column
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(artists, key = { it.name }) { artist ->
                ListItem(
                    modifier = Modifier.clickable { onArtist(artist) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    leadingContent = {
                        Box(
                            Modifier.size(52.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                artist.name.firstOrNull()?.uppercase() ?: "?",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                        }
                    },
                    headlineContent = { Text(artist.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = {
                        Text("${songCount(artist.songs.size)}, ${if (artist.albumCount == 1) "1 album" else "${artist.albumCount} albums"}")
                    },
                )
            }
        }
    }
}
