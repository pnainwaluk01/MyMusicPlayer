package com.mymusicplayer

import android.app.Application
import android.content.Context
import com.mymusicplayer.data.MusicFolderManager
import com.mymusicplayer.data.MusicRepository
import com.mymusicplayer.data.UserPrefs
import com.mymusicplayer.playback.PlayerConnection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MusicApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // First launch: create Music/MyMusicPlayer right away (no permission needed on Android 11+).
        container.appScope.launch(Dispatchers.IO) { container.folderManager.ensureFolder() }
    }
}

/** Tiny manual DI container. */
class AppContainer(context: Context) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val folderManager = MusicFolderManager()
    val prefs = UserPrefs(context)
    val repository = MusicRepository(context.applicationContext, folderManager)
    val player = PlayerConnection(context.applicationContext, appScope, repository, prefs)
}
