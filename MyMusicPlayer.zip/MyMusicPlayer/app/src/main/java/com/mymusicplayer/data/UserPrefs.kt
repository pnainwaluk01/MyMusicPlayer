package com.mymusicplayer.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore(name = "user_prefs")

enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val sort: SortOrder = SortOrder.TITLE,
)

data class SavedSession(
    val ids: List<String>,
    val index: Int,
    val positionMs: Long,
    val shuffle: Boolean,
    val repeatMode: Int,
    val speed: Float,
)

/** All personal data (favorites, history, play counts) is stored on-device only. */
class UserPrefs(context: Context) {
    private val store = context.applicationContext.dataStore

    private object K {
        val THEME = stringPreferencesKey("theme")
        val DYNAMIC = booleanPreferencesKey("dynamic_color")
        val SORT = stringPreferencesKey("sort")
        val FAVORITES = stringSetPreferencesKey("favorites")
        val RECENT = stringPreferencesKey("recent")
        val COUNTS = stringPreferencesKey("play_counts")
        val Q_IDS = stringPreferencesKey("queue_ids")
        val Q_INDEX = intPreferencesKey("queue_index")
        val Q_POS = longPreferencesKey("queue_position")
        val Q_SHUFFLE = booleanPreferencesKey("queue_shuffle")
        val Q_REPEAT = intPreferencesKey("queue_repeat")
        val Q_SPEED = floatPreferencesKey("queue_speed")
    }

    private val data: Flow<Preferences> = store.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val settings: Flow<AppSettings> = data.map { p ->
        AppSettings(
            theme = p[K.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            dynamicColor = p[K.DYNAMIC] ?: true,
            sort = p[K.SORT]?.let { runCatching { SortOrder.valueOf(it) }.getOrNull() } ?: SortOrder.TITLE,
        )
    }
    val favorites: Flow<Set<String>> = data.map { it[K.FAVORITES] ?: emptySet() }
    val recentlyPlayed: Flow<List<String>> = data.map { decodeList(it[K.RECENT]) }
    val playCounts: Flow<Map<String, Int>> = data.map { decodeCounts(it[K.COUNTS]) }

    suspend fun setTheme(mode: ThemeMode) = store.edit { it[K.THEME] = mode.name }
    suspend fun setDynamicColor(on: Boolean) = store.edit { it[K.DYNAMIC] = on }
    suspend fun setSort(order: SortOrder) = store.edit { it[K.SORT] = order.name }

    suspend fun toggleFavorite(id: String): Boolean {
        var nowFavorite = false
        store.edit { p ->
            val cur = p[K.FAVORITES] ?: emptySet()
            nowFavorite = id !in cur
            p[K.FAVORITES] = if (nowFavorite) cur + id else cur - id
        }
        return nowFavorite
    }

    suspend fun recordPlay(id: String) = store.edit { p ->
        p[K.RECENT] = (listOf(id) + decodeList(p[K.RECENT]).filter { it != id }).take(MAX_RECENT).joinToString(",")
        val counts = decodeCounts(p[K.COUNTS]).toMutableMap()
        counts[id] = (counts[id] ?: 0) + 1
        p[K.COUNTS] = counts.entries.joinToString(",") { "${it.key}:${it.value}" }
    }

    suspend fun clearHistory() = store.edit { it.remove(K.RECENT); it.remove(K.COUNTS) }

    suspend fun saveSession(s: SavedSession) = store.edit { p ->
        p[K.Q_IDS] = s.ids.joinToString(",")
        p[K.Q_INDEX] = s.index
        p[K.Q_POS] = s.positionMs
        p[K.Q_SHUFFLE] = s.shuffle
        p[K.Q_REPEAT] = s.repeatMode
        p[K.Q_SPEED] = s.speed
    }

    suspend fun loadSession(): SavedSession? {
        val p = data.first()
        val ids = decodeList(p[K.Q_IDS])
        if (ids.isEmpty()) return null
        return SavedSession(
            ids = ids,
            index = p[K.Q_INDEX] ?: 0,
            positionMs = p[K.Q_POS] ?: 0L,
            shuffle = p[K.Q_SHUFFLE] ?: false,
            repeatMode = p[K.Q_REPEAT] ?: 0,
            speed = p[K.Q_SPEED] ?: 1f,
        )
    }

    private fun decodeList(raw: String?): List<String> =
        raw?.split(',')?.filter { it.isNotBlank() } ?: emptyList()

    private fun decodeCounts(raw: String?): Map<String, Int> =
        decodeList(raw).mapNotNull { entry ->
            val id = entry.substringBefore(':')
            entry.substringAfter(':', "").toIntOrNull()?.let { id to it }
        }.toMap()

    private companion object { const val MAX_RECENT = 50 }
}
