package com.mymusicplayer.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.mymusicplayer.data.MusicRepository
import com.mymusicplayer.data.Song
import com.mymusicplayer.data.UserPrefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class QueueEntry(val index: Int, val song: Song)

data class PlayerState(
    val connected: Boolean = false,
    val currentSong: Song? = null,
    val currentIndex: Int = -1,
    /** Play/pause button state. Stays steady across song changes. */
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
    /** Songs that will play after the current one, in actual play order (respects shuffle). */
    val upNext: List<QueueEntry> = emptyList(),
    val queueSize: Int = 0,
)

/**
 * UI-side bridge to [PlaybackService] through a Media3 [MediaController].
 * Must be used from the main thread (scope uses Dispatchers.Main).
 */
class PlayerConnection(
    private val context: Context,
    private val scope: CoroutineScope,
    private val repository: MusicRepository,
    private val prefs: UserPrefs,
) {
    private var controller: MediaController? = null
    private var connecting: Deferred<MediaController>? = null
    private var tickerJob: Job? = null
    private var uiVisible = false
    private var restoreAttempted = false

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _sleepEndsAt = MutableStateFlow<Long?>(null)
    val sleepTimerEndsAt: StateFlow<Long?> = _sleepEndsAt.asStateFlow()
    private var sleepJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = refresh()
        override fun onPlayerError(error: PlaybackException) {
            val title = controller?.currentMediaItem?.mediaMetadata?.title ?: "this track"
            notify("Couldn't play “$title”. The file may be corrupted or unsupported, so it was skipped.")
        }
    }

    fun notify(message: String) { _messages.tryEmit(message) }

    // ---- lifecycle -------------------------------------------------------------------------

    fun attachUi() { uiVisible = true; connect() }

    fun detachUi() {
        uiVisible = false
        if (sleepJob?.isActive != true) release()
    }

    private fun connect() {
        if (controller != null || connecting != null) return
        val pending = scope.async {
            val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
            MediaController.Builder(context, token).buildAsync().await()
        }
        connecting = pending
        scope.launch {
            val c = runCatching { pending.await() }.getOrElse { e ->
                if (connecting === pending) connecting = null
                if (e is CancellationException) return@launch
                notify("The player couldn't start. Try reopening the app.")
                return@launch
            }
            controller = c
            connecting = null
            c.addListener(listener)
            refresh()
            startTicker()
        }
    }

    private fun release() {
        tickerJob?.cancel()
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        connecting?.cancel()
        connecting = null
        _state.update { it.copy(connected = false) }
    }

    private suspend fun awaitController(): MediaController? {
        controller?.let { return it }
        connect()
        return runCatching { connecting?.await() }.getOrNull() ?: controller
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else scope.launch { awaitController()?.let(block) }
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive) {
                controller?.let { c ->
                    if (c.isPlaying) _state.update { it.copy(positionMs = c.currentPosition.coerceAtLeast(0L)) }
                }
                delay(500)
            }
        }
    }

    // ---- state -----------------------------------------------------------------------------

    private fun songOf(item: MediaItem): Song =
        repository.songFor(item.mediaId) ?: Song.placeholder(
            item.mediaId,
            item.mediaMetadata.title?.toString(),
            item.mediaMetadata.artist?.toString(),
            item.mediaMetadata.albumTitle?.toString(),
        )

    private fun refresh() {
        val c = controller ?: return
        val timeline = c.currentTimeline
        val current = c.currentMediaItemIndex

        val upNext = buildList {
            if (!timeline.isEmpty && current in 0 until timeline.windowCount) {
                var i = timeline.getNextWindowIndex(current, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
                var guard = 0
                while (i != C.INDEX_UNSET && guard < timeline.windowCount) {
                    add(QueueEntry(i, songOf(c.getMediaItemAt(i))))
                    i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
                    guard++
                }
            }
        }
        val song = c.currentMediaItem?.let(::songOf)
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: song?.durationMs ?: 0L

        _state.value = PlayerState(
            connected = true,
            currentSong = song,
            currentIndex = current,
            isPlaying = c.wantsToPlay(),
            isBuffering = c.playbackState == Player.STATE_BUFFERING,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = duration,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            speed = c.playbackParameters.speed,
            hasNext = c.hasNextMediaItem(),
            hasPrevious = c.hasPreviousMediaItem(),
            upNext = upNext,
            queueSize = c.mediaItemCount,
        )
    }

    /** True when playback is on or about to be (buffering the next song), so the button doesn't flicker. */
    private fun Player.wantsToPlay(): Boolean =
        playWhenReady &&
            playbackState != Player.STATE_IDLE &&
            playbackState != Player.STATE_ENDED &&
            playbackSuppressionReason == Player.PLAYBACK_SUPPRESSION_REASON_NONE

    // ---- commands --------------------------------------------------------------------------

    fun playSongs(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean = false) {
        if (songs.isEmpty()) return
        withController { c -> playSongsNow(c, songs, startIndex, shuffle) }
    }

    fun playSongsNow(c: MediaController, songs: List<Song>, startIndex: Int = 0, shuffle: Boolean = false) {
        if (songs.isEmpty()) return
        c.setMediaItems(songs.map { it.toMediaItem() }, startIndex.coerceIn(songs.indices), 0L)
        c.shuffleModeEnabled = shuffle
        c.prepare()
        c.play()
    }

    fun shuffleAll(songs: List<Song>) {
        if (songs.isEmpty()) return
        playSongs(songs, songs.indices.random(), shuffle = true)
    }

    fun togglePlayPause() = withController { c -> togglePlayPauseNow(c) }

    fun togglePlayPauseNow(c: MediaController) {
        when {
            c.wantsToPlay() -> c.pause()
            c.playbackState == Player.STATE_IDLE -> { c.prepare(); c.play() }
            c.playbackState == Player.STATE_ENDED -> { c.seekToDefaultPosition(0); c.play() }
            else -> c.play()
        }
    }

    /** Stop: release decoders, keep the queue, rewind the current song. */
    fun stop() = withController { c ->
        c.stop()
        c.seekTo(c.currentMediaItemIndex, 0L)
        refresh()
    }

    fun next() = withController { it.seekToNext() }
    fun previous() = withController { it.seekToPrevious() } // restarts the song if >3 s in
    fun seekBack() = withController { it.seekBack() }
    fun seekForward() = withController { it.seekForward() }

    fun seekTo(positionMs: Long) = withController { c ->
        c.seekTo(positionMs)
        _state.update { it.copy(positionMs = positionMs) }
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = withController { c ->
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeed(speed: Float) = withController { it.setPlaybackSpeed(speed) }

    fun playQueueIndex(index: Int) = withController { c ->
        c.seekToDefaultPosition(index)
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        c.play()
    }

    fun removeFromQueue(index: Int) = withController { it.removeMediaItem(index) }

    fun playNext(song: Song) = withController { c ->
        if (c.mediaItemCount == 0) playSongs(listOf(song))
        else c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
        notify("“${song.title}” will play next")
    }

    fun addToQueue(song: Song) = withController { c ->
        if (c.mediaItemCount == 0) playSongs(listOf(song))
        else c.addMediaItem(song.toMediaItem())
        notify("Added “${song.title}” to the queue")
    }

    /** Re-loads the last queue (paused) once per process, after the library is known. */
    fun restoreLastSession() {
        if (restoreAttempted) return
        restoreAttempted = true
        scope.launch { awaitController()?.let { restoreSessionNow(it) } }
    }

    /** Puts the saved queue back into the player without starting playback. Returns true if restored. */
    suspend fun restoreSessionNow(c: MediaController): Boolean {
        restoreAttempted = true
        if (c.mediaItemCount > 0) return true
        val saved = prefs.loadSession() ?: return false
        val savedCurrent = saved.ids.getOrNull(saved.index)
        val songs = saved.ids.mapNotNull { repository.songFor(it) }
        if (songs.isEmpty()) return false
        val idx = songs.indexOfFirst { it.mediaId == savedCurrent }
        c.setMediaItems(songs.map { it.toMediaItem() }, idx.coerceAtLeast(0), if (idx >= 0) saved.positionMs else 0L)
        c.shuffleModeEnabled = saved.shuffle
        c.repeatMode = saved.repeatMode
        c.setPlaybackSpeed(saved.speed)
        c.prepare()
        return true
    }

    /**
     * Runs a command coming from a home-screen widget, even when the app isn't open:
     * connects to the service, loads the library and last queue if needed, then lets go again.
     */
    suspend fun runFromWidget(block: suspend PlayerConnection.(MediaController, List<Song>) -> Unit) {
        val c = awaitController() ?: return
        if (!repository.library.value.hasScanned) repository.scan(full = false)
        val songs = repository.library.value.songs
        if (c.mediaItemCount == 0) restoreSessionNow(c)
        block(c, songs)
        if (!uiVisible) {
            scope.launch {
                delay(3_000)
                if (!uiVisible && sleepJob?.isActive != true) release()
            }
        }
    }

    // ---- sleep timer (fades out, then pauses) ----------------------------------------------

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        _sleepEndsAt.value = null
        if (minutes == null || minutes <= 0) return
        val endsAt = System.currentTimeMillis() + minutes * 60_000L
        _sleepEndsAt.value = endsAt
        sleepJob = scope.launch {
            delay((endsAt - System.currentTimeMillis() - FADE_MS).coerceAtLeast(0L))
            val c = awaitController() ?: return@launch
            val startVolume = c.volume
            try {
                val steps = 20
                repeat(steps) { i ->
                    c.volume = startVolume * (1f - (i + 1f) / steps)
                    delay(FADE_MS / steps)
                }
                c.pause()
            } finally {
                c.volume = startVolume
                _sleepEndsAt.value = null
                if (!uiVisible) release()
            }
        }
    }

    private companion object { const val FADE_MS = 10_000L }
}
