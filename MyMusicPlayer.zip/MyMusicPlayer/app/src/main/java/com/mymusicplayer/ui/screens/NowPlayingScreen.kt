package com.mymusicplayer.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import com.mymusicplayer.ui.components.ArtworkLoader
import com.mymusicplayer.ui.components.MorphPlayButton
import com.mymusicplayer.ui.components.WavySeekBar
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.mymusicplayer.playback.PlayerState
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.components.Artwork
import com.mymusicplayer.util.formatDuration
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit) {
    val s by vm.playerState.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val sleepEndsAt by vm.sleepTimerEndsAt.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    var showQueue by rememberSaveable { mutableStateOf(false) }
    var showSleep by rememberSaveable { mutableStateOf(false) }
    var showSpeed by rememberSaveable { mutableStateOf(false) }

    val song = s.currentSong
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    // Tint the screen with the album cover's colour, like the Hello UI media player.
    val artColor by produceState<Color?>(null, song?.id) {
        value = song?.let { ArtworkLoader.dominantColor(context, it) }
    }
    val tint by animateColorAsState(
        artColor?.let { lerp(scheme.surface, it, 0.45f) } ?: scheme.primaryContainer,
        tween(600), label = "tint",
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(0f to tint, 0.55f to scheme.surface, 1f to scheme.surface),
        ),
    ) {
        if (song == null) {
            Column(Modifier.fillMaxSize().systemBarsPadding(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Nothing is playing", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onClose) { Text("Back to library") }
            }
            return@Box
        }

        BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
            val landscape = maxWidth > maxHeight && maxWidth >= 560.dp
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close player") }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Now playing", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                        Text(song.album, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { showQueue = true }) {
                        Icon(Icons.AutoMirrored.Rounded.QueueMusic, contentDescription = "Queue")
                    }
                }

                val art: @Composable (Modifier) -> Unit = { m ->
                    Crossfade(targetState = song, label = "art", modifier = m) { target ->
                        Artwork(
                            target,
                            Modifier.fillMaxSize().shadow(24.dp, RoundedCornerShape(36.dp)),
                            sizeHint = 720.dp, corner = 36.dp,
                        )
                    }
                }

                if (landscape) {
                    Row(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 32.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(40.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            art(Modifier.aspectRatio(1f, matchHeightConstraintsFirst = true))
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Controls(s, vm, song.mediaId in favorites, sleepEndsAt, { showSleep = true }, { showSpeed = true }, { showQueue = true }, { vm.shuffle(library.songs) })
                        }
                    }
                } else {
                    Column(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                            art(Modifier.widthIn(max = 520.dp).aspectRatio(1f, matchHeightConstraintsFirst = true))
                        }
                        Column(Modifier.widthIn(max = 560.dp)) {
                            Controls(s, vm, song.mediaId in favorites, sleepEndsAt, { showSleep = true }, { showSpeed = true }, { showQueue = true }, { vm.shuffle(library.songs) })
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    }

    if (showQueue) QueueSheet(s, vm) { showQueue = false }
    if (showSleep) SleepTimerDialog(sleepEndsAt, onPick = { vm.setSleepTimer(it); showSleep = false }) { showSleep = false }
    if (showSpeed) SpeedDialog(s.speed, onPick = { vm.setSpeed(it); showSpeed = false }) { showSpeed = false }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ColumnScope.Controls(
    s: PlayerState,
    vm: MainViewModel,
    isFavorite: Boolean,
    sleepEndsAt: Long?,
    onSleep: () -> Unit,
    onSpeed: () -> Unit,
    onQueue: () -> Unit,
    onShuffleAll: () -> Unit,
) {
    val song = s.currentSong ?: return
    val scheme = MaterialTheme.colorScheme

    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(song.title, style = MaterialTheme.typography.headlineSmall, maxLines = 1, modifier = Modifier.basicMarquee())
            Text(song.artist, style = MaterialTheme.typography.titleMedium, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = { vm.toggleFavorite(song) }) {
            Icon(
                if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                tint = if (isFavorite) scheme.primary else scheme.onSurfaceVariant,
            )
        }
    }
    val meta = listOfNotNull(song.format.takeIf { it.isNotEmpty() }, song.year.takeIf { it > 0 }?.toString())
    if (meta.isNotEmpty()) {
        Text(meta.joinToString("  "), style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant)
    }

    Spacer(Modifier.height(12.dp))
    WavySeekBar(s.positionMs, s.durationMs, s.isPlaying, onSeek = vm::seekTo)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = vm::toggleShuffle) {
            Icon(
                Icons.Rounded.Shuffle, contentDescription = if (s.shuffle) "Shuffle on" else "Shuffle off",
                tint = if (s.shuffle) scheme.primary else scheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = vm::previous, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
        }
        Box(contentAlignment = Alignment.Center) {
            MorphPlayButton(isPlaying = s.isPlaying, onClick = vm::togglePlayPause)
            if (s.isBuffering) CircularProgressIndicator(Modifier.size(36.dp), color = scheme.onPrimary, strokeWidth = 3.dp)
        }
        IconButton(onClick = vm::next, enabled = s.hasNext, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
        }
        IconButton(onClick = vm::cycleRepeat) {
            Icon(
                if (s.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                contentDescription = when (s.repeatMode) {
                    Player.REPEAT_MODE_ONE -> "Repeat one"; Player.REPEAT_MODE_ALL -> "Repeat all"; else -> "Repeat off"
                },
                tint = if (s.repeatMode != Player.REPEAT_MODE_OFF) scheme.primary else scheme.onSurfaceVariant,
            )
        }
    }

    Spacer(Modifier.height(12.dp))
    Surface(shape = RoundedCornerShape(50), color = scheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = vm::seekBack) { Icon(Icons.Rounded.Replay10, contentDescription = "Back 10 seconds") }
        IconButton(onClick = vm::stop) { Icon(Icons.Rounded.Stop, contentDescription = "Stop") }
        SleepButton(sleepEndsAt, onSleep)
        TextButton(onClick = onSpeed) {
            Icon(Icons.Rounded.Speed, null, Modifier.size(18.dp))
            Spacer(Modifier.size(4.dp))
            Text(speedLabel(s.speed))
        }
        IconButton(onClick = vm::seekForward) { Icon(Icons.Rounded.Forward10, contentDescription = "Forward 10 seconds") }
    }
    }

    Spacer(Modifier.height(8.dp))
    UpNextCard(s, onQueue, onShuffleAll)
}

/**
 * Always the same height, so nothing shifts on the last song.
 * Shows the next song, or what happens at the end of the queue (with a Shuffle all shortcut).
 */
@Composable
private fun UpNextCard(s: PlayerState, onQueue: () -> Unit, onShuffleAll: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val next = s.upNext.firstOrNull()
    Surface(
        onClick = onQueue,
        shape = RoundedCornerShape(24.dp),
        color = scheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth().height(64.dp),
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (next != null) {
                Artwork(next.song, Modifier.size(40.dp), sizeHint = 40.dp, corner = 14.dp)
            } else {
                Box(
                    Modifier.size(40.dp).background(scheme.secondaryContainer, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        when (s.repeatMode) {
                            Player.REPEAT_MODE_ONE -> Icons.Rounded.RepeatOne
                            Player.REPEAT_MODE_ALL -> Icons.Rounded.Repeat
                            else -> Icons.AutoMirrored.Rounded.QueueMusic
                        },
                        contentDescription = null, tint = scheme.onSecondaryContainer, modifier = Modifier.size(22.dp),
                    )
                }
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                val (label, title) = when {
                    s.repeatMode == Player.REPEAT_MODE_ONE -> "Repeat one" to "This song plays again"
                    next != null -> "Up next" to next.song.title
                    s.repeatMode == Player.REPEAT_MODE_ALL -> "Repeat all" to "Queue starts over"
                    else -> "End of queue" to "Music stops after this song"
                }
                Text(label, style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant)
                Text(title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (next == null && s.repeatMode == Player.REPEAT_MODE_OFF) {
                FilledTonalButton(onClick = onShuffleAll, contentPadding = PaddingValues(horizontal = 14.dp)) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Shuffle all")
                }
            } else if (next != null) {
                Text("${s.upNext.size}", style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SleepButton(endsAt: Long?, onClick: () -> Unit) {
    val remaining by produceState(0L, endsAt) {
        while (endsAt != null) {
            value = (endsAt - System.currentTimeMillis()).coerceAtLeast(0L)
            delay(1_000)
        }
        value = 0L
    }
    TextButton(onClick = onClick) {
        Icon(
            Icons.Rounded.Bedtime, null, Modifier.size(18.dp),
            tint = if (endsAt != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (endsAt != null) {
            Spacer(Modifier.size(4.dp))
            Text(formatDuration(remaining))
        } else {
            Spacer(Modifier.size(4.dp))
            Text("Sleep")
        }
    }
}

private fun speedLabel(speed: Float): String =
    if (speed == speed.toInt().toFloat()) "${speed.toInt()}×" else "${speed}×"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QueueSheet(s: PlayerState, vm: MainViewModel, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text("Queue", style = MaterialTheme.typography.titleLarge)
            Text(
                if (s.shuffle) "Shuffled, ${s.queueSize} songs" else "${s.queueSize} songs",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        s.currentSong?.let { cur ->
            ListItem(
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                overlineContent = { Text("Playing") },
                headlineContent = { Text(cur.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.primary) },
                supportingContent = { Text(cur.artist, maxLines = 1) },
                leadingContent = { Artwork(cur, Modifier.size(48.dp), sizeHint = 48.dp) },
            )
        }
        if (s.upNext.isEmpty()) {
            Text(
                "Nothing else is queued. Use “Play next” or “Add to queue” from any song’s menu.",
                Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            Text("Up next", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(start = 20.dp, top = 8.dp))
            LazyColumn(Modifier.fillMaxWidth().fillMaxHeight(0.75f)) {
                items(s.upNext, key = { it.index }) { entry ->
                    ListItem(
                        modifier = Modifier.clickable { vm.playQueueIndex(entry.index) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        headlineContent = { Text(entry.song.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(entry.song.artist, maxLines = 1) },
                        leadingContent = { Artwork(entry.song, Modifier.size(44.dp), sizeHint = 44.dp) },
                        trailingContent = {
                            IconButton(onClick = { vm.removeFromQueue(entry.index) }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Remove ${entry.song.title} from queue")
                            }
                        },
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SleepTimerDialog(endsAt: Long?, onPick: (Int?) -> Unit, onDismiss: () -> Unit) {
    val options = listOf(5, 10, 15, 30, 45, 60, 90)
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Bedtime, null) },
        title = { Text("Sleep timer") },
        text = {
            Column {
                Text(
                    "Music fades out over 10 seconds, then pauses.",
                    style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Start,
                )
                Spacer(Modifier.height(8.dp))
                options.forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = false, role = Role.Button) { onPick(m) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(if (m < 60) "$m minutes" else if (m == 60) "1 hour" else "1 h 30 min")
                    }
                }
            }
        },
        confirmButton = { if (endsAt != null) TextButton(onClick = { onPick(null) }) { Text("Turn off timer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SpeedDialog(current: Float, onPick: (Float) -> Unit, onDismiss: () -> Unit) {
    val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback speed") },
        text = {
            Column {
                speeds.forEach { sp ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = sp == current, role = Role.RadioButton) { onPick(sp) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = sp == current, onClick = null)
                        Spacer(Modifier.size(8.dp))
                        Text(if (sp == 1f) "Normal" else speedLabel(sp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}
