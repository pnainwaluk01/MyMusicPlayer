package com.mymusicplayer.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mymusicplayer.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.math.abs

/** Loads embedded album art from the audio file itself — no network, no image library. */
object ArtworkLoader {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val missing: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val gate = Semaphore(3)

    private fun key(song: Song, px: Int) = "${song.id}@$px"

    fun cached(song: Song, px: Int): ImageBitmap? = cache.get(key(song, px))?.asImageBitmap()

    fun clear() { cache.evictAll(); missing.clear(); colors.clear() }

    private val colors = java.util.concurrent.ConcurrentHashMap<Long, Int>()

    /** Average colour of the cover, used to tint the Now Playing screen. Null if no artwork. */
    suspend fun dominantColor(context: Context, song: Song): Color? {
        colors[song.id]?.let { return Color(it) }
        val small = load(context, song, 96)?.asAndroidBitmap() ?: return null
        val argb = withContext(Dispatchers.Default) {
            Bitmap.createScaledBitmap(small.copy(Bitmap.Config.ARGB_8888, false), 1, 1, true).getPixel(0, 0)
        }
        colors[song.id] = argb
        return Color(argb)
    }

    suspend fun load(context: Context, song: Song, px: Int): ImageBitmap? {
        val key = key(song, px)
        cache.get(key)?.let { return it.asImageBitmap() }
        if (key in missing || song.uri == Uri.EMPTY) return null
        return gate.withPermit {
            withContext(Dispatchers.IO) {
                val bmp = decode(context, song.uri, px)
                if (bmp != null) cache.put(key, bmp) else missing.add(key)
                bmp?.asImageBitmap()
            }
        }
    }

    private fun decode(context: Context, uri: Uri, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { return context.contentResolver.loadThumbnail(uri, Size(px, px), null) }
        }
        return runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, uri)
                val bytes = r.embeddedPicture ?: return null
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            } finally {
                r.release()
            }
        }.getOrNull()
    }
}

private val placeholderPalettes = listOf(
    Color(0xFF3A3F8F) to Color(0xFF1B1F3B),
    Color(0xFFF2A93B) to Color(0xFFB8641A),
    Color(0xFF2BB3A3) to Color(0xFF125E57),
    Color(0xFF8E5BB8) to Color(0xFF3A1F59),
    Color(0xFFD9566C) to Color(0xFF6B1E33),
)

/**
 * Album art with a generated placeholder when a file has no embedded picture.
 * [sizeHint] controls decode resolution; layout size comes from [modifier].
 */
@Composable
fun Artwork(
    song: Song?,
    modifier: Modifier = Modifier,
    sizeHint: Dp = 56.dp,
    corner: Dp = 8.dp,
) {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { sizeHint.roundToPx() }.coerceIn(64, 1024)
    val bitmap by produceState(initialValue = song?.let { ArtworkLoader.cached(it, px) }, song?.id, px) {
        value = song?.let { ArtworkLoader.cached(it, px) }
        if (value == null && song != null) value = ArtworkLoader.load(context, song, px)
    }
    Box(modifier.clip(RoundedCornerShape(corner)), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        if (bmp != null) {
            Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            val (a, b) = placeholderPalettes[abs((song?.album ?: "").hashCode()) % placeholderPalettes.size]
            Box(
                Modifier.fillMaxSize().background(Brush.linearGradient(listOf(a, b))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.MusicNote, contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.fillMaxSize(0.42f),
                )
            }
        }
    }
}
