package com.mymusicplayer.ui.screens

import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mymusicplayer.data.Song
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.components.Artwork
import com.mymusicplayer.ui.components.songItems

/** Album, artist and smart-list detail screen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(
    vm: MainViewModel,
    title: String,
    subtitle: String?,
    songs: List<Song>,
    cover: Song?,
    emptyHint: String,
    onBack: () -> Unit,
) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val player by vm.playerState.collectAsStateWithLifecycle()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Column(Modifier.fillMaxSize().nestedScroll(scroll.nestedScrollConnection)) {
        LargeTopAppBar(
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") }
            },
            scrollBehavior = scroll,
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item(key = "hero") {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(cover, Modifier.size(132.dp), sizeHint = 132.dp, corner = 32.dp)
                    Spacer(Modifier.size(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${songs.size} songs", style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        if (subtitle != null) {
                            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (songs.isEmpty()) {
                item(key = "empty") {
                    Text(emptyHint, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                item(key = "actions") { PlayHeader(songs, onPlay = { vm.play(songs, 0) }, onShuffle = { vm.shuffle(songs) }) }
                songItems(songs, player.currentSong?.mediaId, player.isPlaying, favorites, vm)
            }
        }
    }
}
