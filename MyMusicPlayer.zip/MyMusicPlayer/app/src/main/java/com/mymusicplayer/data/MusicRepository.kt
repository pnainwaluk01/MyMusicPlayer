package com.mymusicplayer.data

import android.content.ContentUris
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.mymusicplayer.MusicConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume

/**
 * Scans ONLY the dedicated folder. Everything is local: File listing + MediaScanner + MediaStore.
 */
class MusicRepository(
    private val context: Context,
    private val folderManager: MusicFolderManager,
) {
    private val _library = MutableStateFlow(LibraryState())
    val library: StateFlow<LibraryState> = _library.asStateFlow()

    @Volatile private var byId: Map<String, Song> = emptyMap()
    fun songFor(mediaId: String): Song? = byId[mediaId]

    private val mutex = Mutex()

    /**
     * @param full true = re-index every file (picks up edited tags); false = only new/removed files.
     */
    suspend fun scan(full: Boolean): LibraryState = mutex.withLock {
        _library.update { it.copy(isScanning = true, error = null) }
        val result = withContext(Dispatchers.IO) { runCatching { doScan(full) } }
        val newState = result.getOrElse { e ->
            _library.value.copy(error = e.message ?: "Scanning failed")
        }.copy(isScanning = false, hasScanned = true)
        byId = newState.songs.associateBy { it.mediaId }
        _library.value = newState
        newState
    }

    private suspend fun doScan(full: Boolean): LibraryState {
        val status = folderManager.ensureFolder()
        val dir = folderManager.folder

        val files = listFiles(dir)
        val (audio, other) = files.partition { it.extension.lowercase() in MusicConfig.SUPPORTED_EXTENSIONS }

        // Make sure MediaStore knows about new/changed files and forgets deleted ones.
        val known = _library.value.songs.associateBy { it.path }
        val toScan = buildSet {
            audio.forEach { f -> if (full || f.absolutePath !in known) add(f.absolutePath) }
            known.keys.forEach { p -> if (p.isNotEmpty() && !File(p).exists()) add(p) }
        }
        if (toScan.isNotEmpty()) scanPaths(toScan.toList())

        val songs = queryMediaStore(dir).filter { it.path.isEmpty() || File(it.path).exists() }
        val indexed = songs.mapTo(HashSet()) { it.path }

        return LibraryState(
            songs = songs,
            folderStatus = status,
            ignoredFiles = other.filterNot { it.name.startsWith(".") }.map { it.name },
            unreadableFiles = audio.filter { it.absolutePath !in indexed }.map { it.name },
            lastScanMs = System.currentTimeMillis(),
        )
    }

    private fun listFiles(dir: File): List<File> = runCatching {
        dir.walkTopDown()
            .maxDepth(if (MusicConfig.INCLUDE_SUBFOLDERS) 8 else 1)
            .filter { it.isFile }
            .toList()
    }.getOrDefault(emptyList())

    private suspend fun scanPaths(paths: List<String>) {
        withTimeoutOrNull(20_000) {
            suspendCancellableCoroutine<Unit> { cont ->
                val remaining = AtomicInteger(paths.size)
                MediaScannerConnection.scanFile(context, paths.toTypedArray(), null) { _, _ ->
                    if (remaining.decrementAndGet() == 0 && cont.isActive) cont.resume(Unit)
                }
            }
        }
    }

    /** Untagged files get their file name as title; make that readable ("My_song" -> "My song"). */
    private fun cleanTitle(raw: String?, fileName: String): String {
        val base = fileName.substringBeforeLast('.')
        val t = raw?.takeIf { it.isNotBlank() } ?: base
        return if (t == base) t.replace('_', ' ').replace(Regex("\\s+"), " ").trim() else t
    }

    @Suppress("DEPRECATION") // DATA is still populated and is the only path column below API 29
    private fun queryMediaStore(dir: File): List<Song> {
        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DISPLAY_NAME,
        )
        val (selection, args) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rel = MusicConfig.RELATIVE_PATH
            if (MusicConfig.INCLUDE_SUBFOLDERS) "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?" to arrayOf("$rel%")
            else "${MediaStore.Audio.Media.RELATIVE_PATH} = ?" to arrayOf(rel)
        } else {
            "${MediaStore.Audio.Media.DATA} LIKE ?" to arrayOf("${dir.absolutePath}/%")
        }

        val songs = mutableListOf<Song>()
        context.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val trackCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)

            while (c.moveToNext()) {
                val name = c.getString(nameCol).orEmpty()
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in MusicConfig.SUPPORTED_EXTENSIONS) continue
                val path = c.getString(dataCol).orEmpty()
                if (!MusicConfig.INCLUDE_SUBFOLDERS && path.isNotEmpty() && File(path).parentFile != dir) continue

                val id = c.getLong(idCol)
                songs += Song(
                    id = id,
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                    title = cleanTitle(c.getString(titleCol), name),
                    artist = c.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: Song.UNKNOWN_ARTIST,
                    album = c.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: Song.UNKNOWN_ALBUM,
                    albumId = c.getLong(albumIdCol),
                    durationMs = c.getLong(durCol),
                    path = path,
                    dateAddedSec = c.getLong(addedCol),
                    sizeBytes = c.getLong(sizeCol),
                    track = c.getInt(trackCol),
                    year = c.getInt(yearCol),
                    format = ext.uppercase(),
                )
            }
        }
        return songs
    }
}
