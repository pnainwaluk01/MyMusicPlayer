package com.mymusicplayer.ui.screens

import android.os.Build
import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mymusicplayer.BuildConfig
import com.mymusicplayer.data.FolderStatus
import com.mymusicplayer.data.ThemeMode
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.components.FolderPathCard
import com.mymusicplayer.util.formatSize
import com.mymusicplayer.util.formatTotalTime
import com.mymusicplayer.util.songCount
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val lib by vm.library.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Settings") })
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Section("Music folder") }
            item { FolderPathCard(vm.friendlyPath, vm.absolutePath, Modifier.widthIn(max = 720.dp)) }
            item {
                Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (val st = lib.folderStatus) {
                            is FolderStatus.Ready -> StatusLine(true, if (st.createdNow) "Folder created" else "Folder ready")
                            is FolderStatus.Unavailable -> StatusLine(false, st.reason)
                            null -> StatusLine(true, "Checking folder…")
                        }
                        if (lib.lastScanMs > 0) {
                            val time = DateFormat.getTimeFormat(context).format(Date(lib.lastScanMs))
                            Text("Last scan at $time found ${songCount(lib.songs.size)}.", style = MaterialTheme.typography.bodyMedium)
                        }
                        if (lib.ignoredFiles.isNotEmpty()) {
                            Text(
                                "Skipped ${lib.ignoredFiles.size} file(s) that aren't supported audio: " +
                                    lib.ignoredFiles.take(5).joinToString(", ") + if (lib.ignoredFiles.size > 5) ", …" else "",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (lib.unreadableFiles.isNotEmpty()) {
                            Text(
                                "${lib.unreadableFiles.size} audio file(s) couldn't be read and may be damaged: " +
                                    lib.unreadableFiles.take(5).joinToString(", "),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
                            )
                        }
                        lib.error?.let { Text("Last scan failed: $it", color = MaterialTheme.colorScheme.error) }
                        Button(onClick = { vm.scan(full = true) }, enabled = !lib.isScanning) {
                            if (lib.isScanning) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Rounded.Refresh, null)
                            Spacer(Modifier.size(8.dp))
                            Text(if (lib.isScanning) "Scanning…" else "Rescan folder")
                        }
                    }
                }
            }

            item { Section("Appearance") }
            item {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    ThemeMode.entries.forEachIndexed { i, mode ->
                        SegmentedButton(
                            selected = settings.theme == mode,
                            onClick = { vm.setTheme(mode) },
                            shape = SegmentedButtonDefaults.itemShape(i, ThemeMode.entries.size),
                        ) { Text(mode.label) }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                item {
                    ListItem(
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        headlineContent = { Text("Use wallpaper colors") },
                        supportingContent = { Text("Match the app to your device's Material You palette") },
                        trailingContent = { Switch(checked = settings.dynamicColor, onCheckedChange = vm::setDynamicColor) },
                    )
                }
            }

            item { Section("Your library") }
            item {
                Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Stat("Songs", lib.songs.size.toString())
                        Stat("Albums", albums.size.toString())
                        Stat("Artists", artists.size.toString())
                        Stat("Total time", formatTotalTime(lib.songs.sumOf { it.durationMs }))
                        Stat("Space used", formatSize(lib.songs.sumOf { it.sizeBytes }))
                    }
                }
            }

            item { Section("Privacy") }
            item {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text("Fully offline", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(
                                "The app has no internet permission, so it can't upload or share your music. Favorites, history and play counts stay on this phone.",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                        }
                    }
                }
            }
            item { OutlinedButton(onClick = vm::clearHistory) { Text("Clear listening history") } }

            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    "MyMusicPlayer ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp))
}

@Composable
private fun StatusLine(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null,
            tint = if (ok) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.size(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
