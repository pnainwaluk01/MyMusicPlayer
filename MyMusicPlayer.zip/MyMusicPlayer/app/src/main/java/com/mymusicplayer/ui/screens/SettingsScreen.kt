package com.mymusicplayer.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mymusicplayer.BuildConfig
import com.mymusicplayer.data.FolderStatus
import com.mymusicplayer.data.ThemeMode
import com.mymusicplayer.ui.MainViewModel
import com.mymusicplayer.ui.components.CardGroup
import com.mymusicplayer.util.formatSize
import com.mymusicplayer.util.formatTotalTime
import com.mymusicplayer.util.songCount
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val lib by vm.library.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val clear = ListItemDefaults.colors(containerColor = Color.Transparent)

    Column(Modifier.fillMaxSize().nestedScroll(scroll.nestedScrollConnection)) {
        LargeTopAppBar(title = { Text("Settings") }, scrollBehavior = scroll)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Section("Music folder") }
            item {
                CardGroup {
                    item(onClick = { copy(context, vm.absolutePath) }) {
                        ListItem(
                            colors = clear,
                            leadingContent = { Icon(Icons.Rounded.Folder, null) },
                            headlineContent = { Text(vm.friendlyPath) },
                            supportingContent = {
                                SelectionContainer { Text(vm.absolutePath, fontFamily = FontFamily.Monospace) }
                            },
                            trailingContent = { Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy path") },
                        )
                    }
                    item {
                        val (ok, text) = when (val st = lib.folderStatus) {
                            is FolderStatus.Ready -> true to (if (st.createdNow) "Folder created" else "Folder ready")
                            is FolderStatus.Unavailable -> false to st.reason
                            null -> true to "Checking folder…"
                        }
                        ListItem(
                            colors = clear,
                            leadingContent = {
                                Icon(
                                    if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null,
                                    tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                )
                            },
                            headlineContent = { Text(text) },
                            supportingContent = {
                                Column {
                                    if (lib.lastScanMs > 0) {
                                        val time = DateFormat.getTimeFormat(context).format(Date(lib.lastScanMs))
                                        Text("Last scan at $time found ${songCount(lib.songs.size)}")
                                    }
                                    if (lib.ignoredFiles.isNotEmpty()) {
                                        Text("Skipped ${lib.ignoredFiles.size} unsupported file(s): " + lib.ignoredFiles.take(4).joinToString(", "))
                                    }
                                    if (lib.unreadableFiles.isNotEmpty()) {
                                        Text(
                                            "${lib.unreadableFiles.size} file(s) couldn't be read and may be damaged: " + lib.unreadableFiles.take(4).joinToString(", "),
                                            color = MaterialTheme.colorScheme.error,
                                        )
                                    }
                                    lib.error?.let { Text("Last scan failed: $it", color = MaterialTheme.colorScheme.error) }
                                }
                            },
                        )
                    }
                    item(onClick = { if (!lib.isScanning) vm.scan(full = true) }) {
                        ListItem(
                            colors = clear,
                            leadingContent = {
                                if (lib.isScanning) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Rounded.Refresh, null)
                            },
                            headlineContent = { Text(if (lib.isScanning) "Scanning…" else "Rescan folder") },
                            supportingContent = { Text("Find songs you've added, changed or removed") },
                        )
                    }
                }
            }

            item { Section("Appearance") }
            item {
                CardGroup {
                    item {
                        Column(Modifier.padding(16.dp)) {
                            Text("Theme", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(12.dp))
                            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                                ThemeMode.entries.forEachIndexed { i, mode ->
                                    SegmentedButton(
                                        selected = settings.theme == mode,
                                        onClick = { vm.setTheme(mode) },
                                        shape = SegmentedButtonDefaults.itemShape(i, ThemeMode.entries.size),
                                    ) { Text(mode.label) }
                                }
                            }
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        item(onClick = { vm.setDynamicColor(!settings.dynamicColor) }) {
                            ListItem(
                                colors = clear,
                                leadingContent = { Icon(Icons.Rounded.Palette, null) },
                                headlineContent = { Text("Wallpaper colors") },
                                supportingContent = { Text("Match the app to your wallpaper and system style") },
                                trailingContent = { Switch(checked = settings.dynamicColor, onCheckedChange = vm::setDynamicColor) },
                            )
                        }
                    }
                }
            }

            item { Section("Your library") }
            item {
                CardGroup {
                    item { Stat("Songs", lib.songs.size.toString()) }
                    item { Stat("Albums", albums.size.toString()) }
                    item { Stat("Artists", artists.size.toString()) }
                    item { Stat("Total time", formatTotalTime(lib.songs.sumOf { it.durationMs })) }
                    item { Stat("Space used", formatSize(lib.songs.sumOf { it.sizeBytes })) }
                }
            }

            item { Section("Privacy") }
            item {
                CardGroup {
                    item {
                        ListItem(
                            colors = clear,
                            leadingContent = { Icon(Icons.Rounded.Lock, null) },
                            headlineContent = { Text("Fully offline") },
                            supportingContent = {
                                Text("Music has no internet permission, so it can't upload or share your files. Favorites, history and play counts stay on this phone.")
                            },
                        )
                    }
                    item(onClick = { vm.clearHistory() }) {
                        ListItem(
                            colors = clear,
                            leadingContent = { Icon(Icons.Rounded.DeleteSweep, null) },
                            headlineContent = { Text("Clear listening history") },
                            supportingContent = { Text("Resets Recently played and Most played") },
                        )
                    }
                }
            }

            item {
                Text(
                    "Music ${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun copy(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Music folder", text))
    android.widget.Toast.makeText(context, "Folder path copied", android.widget.Toast.LENGTH_SHORT).show()
}
