package com.mymusicplayer.data

import android.net.Uri

data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val dateAddedSec: Long,
    val sizeBytes: Long,
    val track: Int,
    val year: Int,
    val format: String,
) {
    val mediaId: String get() = id.toString()
    val trackNumber: Int get() = track % 1000

    companion object {
        fun placeholder(mediaId: String, title: String?, artist: String?, album: String?) = Song(
            id = mediaId.toLongOrNull() ?: -1L,
            uri = Uri.EMPTY,
            title = title ?: "Unknown title",
            artist = artist ?: UNKNOWN_ARTIST,
            album = album ?: UNKNOWN_ALBUM,
            albumId = -1L, durationMs = 0L, path = "", dateAddedSec = 0L,
            sizeBytes = 0L, track = 0, year = 0, format = "",
        )
        const val UNKNOWN_ARTIST = "Unknown artist"
        const val UNKNOWN_ALBUM = "Unknown album"
    }
}

data class Album(val id: Long, val title: String, val artist: String, val songs: List<Song>) {
    val cover: Song get() = songs.first()
}

data class Artist(val name: String, val songs: List<Song>, val albumCount: Int)

enum class SortOrder(val label: String) {
    TITLE("Title"), ARTIST("Artist"), ALBUM("Album"),
    DATE_ADDED("Recently added"), DURATION("Longest first"),
}

fun List<Song>.applySort(order: SortOrder): List<Song> = when (order) {
    SortOrder.TITLE -> sortedBy { it.title.lowercase() }
    SortOrder.ARTIST -> sortedWith(compareBy({ it.artist.lowercase() }, { it.album.lowercase() }, { it.track }, { it.title.lowercase() }))
    SortOrder.ALBUM -> sortedWith(compareBy({ it.album.lowercase() }, { it.track }, { it.title.lowercase() }))
    SortOrder.DATE_ADDED -> sortedByDescending { it.dateAddedSec }
    SortOrder.DURATION -> sortedByDescending { it.durationMs }
}

sealed interface FolderStatus {
    data class Ready(val createdNow: Boolean) : FolderStatus
    data class Unavailable(val reason: String) : FolderStatus
}

data class LibraryState(
    val isScanning: Boolean = false,
    val hasScanned: Boolean = false,
    val songs: List<Song> = emptyList(),
    val folderStatus: FolderStatus? = null,
    /** Files in the folder that are not a supported audio format. */
    val ignoredFiles: List<String> = emptyList(),
    /** Supported files that the system could not read (often corrupted). */
    val unreadableFiles: List<String> = emptyList(),
    val lastScanMs: Long = 0L,
    val error: String? = null,
)
