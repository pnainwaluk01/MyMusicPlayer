package com.mymusicplayer

import android.os.Environment

/**
 * Single place to configure the dedicated music folder.
 *
 * The folder lives in the PUBLIC shared Music directory (not in app-private storage),
 * so any file manager or a PC over USB can copy songs into it:
 *     Internal storage/Music/MyMusicPlayer/
 */
object MusicConfig {
    /** Name of the folder created inside [PARENT_DIRECTORY]. Change to rename it. */
    const val FOLDER_NAME = "MyMusicPlayer"

    /** Standard public directory that hosts the folder. Must be a MediaStore audio location. */
    val PARENT_DIRECTORY: String = Environment.DIRECTORY_MUSIC

    /** Also pick up songs inside sub-folders (e.g. MyMusicPlayer/Jazz/). */
    const val INCLUDE_SUBFOLDERS = true

    /** MediaStore RELATIVE_PATH form, e.g. "Music/MyMusicPlayer/". */
    val RELATIVE_PATH: String get() = "$PARENT_DIRECTORY/$FOLDER_NAME/"

    val SUPPORTED_EXTENSIONS = setOf("mp3", "wav", "flac", "aac", "m4a", "ogg", "opus")
}
