package com.mymusicplayer.playback

import android.app.PendingIntent
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.mymusicplayer.MusicApp
import com.mymusicplayer.data.SavedSession
import kotlinx.coroutines.launch

/**
 * Owns the ExoPlayer and the MediaSession. Media3 turns this into a foreground service with a
 * media notification while playing, which also gives lock-screen controls, headset/Bluetooth
 * buttons, Android Auto/Wear surfaces and audio-focus handling (calls, other apps).
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private val container get() = (application as MusicApp).container

    private var consecutiveErrors = 0
    private var lastCountedId: String? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true, // pauses for calls, ducks for notifications
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .setWakeMode(C.WAKE_MODE_LOCAL)    // keep CPU alive with the screen off
            .setSeekBackIncrementMs(SEEK_MS)
            .setSeekForwardIncrementMs(SEEK_MS)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // Corrupted or unsupported file: skip it instead of getting stuck.
                consecutiveErrors++
                if (consecutiveErrors < player.mediaItemCount && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.playWhenReady = true
                } else {
                    consecutiveErrors = 0
                    player.stop()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) consecutiveErrors = 0
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) lastCountedId = null
                saveSession(player)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    val id = player.currentMediaItem?.mediaId
                    if (id != null && id != lastCountedId) {
                        lastCountedId = id
                        container.appScope.launch { container.prefs.recordPlay(id) }
                    }
                } else {
                    saveSession(player)
                }
            }
        })

        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val sessionActivity = PendingIntent.getActivity(
            this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        session = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivity)
            .setCallback(SessionCallback())
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 ||
            player.playbackState == Player.STATE_ENDED
        ) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.run {
            saveSession(player)
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    private fun saveSession(player: Player) {
        if (player.mediaItemCount == 0) return
        val s = SavedSession(
            ids = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).mediaId },
            index = player.currentMediaItemIndex,
            positionMs = player.currentPosition.coerceAtLeast(0L),
            shuffle = player.shuffleModeEnabled,
            repeatMode = player.repeatMode,
            speed = player.playbackParameters.speed,
        )
        container.appScope.launch { container.prefs.saveSession(s) }
    }

    /** Controllers may send items without a playable URI; resolve it locally. */
    private inner class SessionCallback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                if (item.localConfiguration != null) item
                else {
                    val uri = item.requestMetadata.mediaUri
                        ?: container.repository.songFor(item.mediaId)?.uri
                    if (uri != null) item.buildUpon().setUri(uri).build() else item
                }
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }

    private companion object { const val SEEK_MS = 10_000L }
}
