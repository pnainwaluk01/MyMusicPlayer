package com.mymusicplayer.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mymusicplayer.util.formatDuration
import kotlin.math.PI
import kotlin.math.sin

/**
 * Android 16 / Hello UI style seek bar: the played part is a moving wave while music plays,
 * flattening when paused or while dragging. Tap or drag anywhere to seek.
 */
@Composable
fun WavySeekBar(
    positionMs: Long,
    durationMs: Long,
    isPlaying: Boolean,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    val dur = durationMs.coerceAtLeast(1L)
    val enabled = durationMs > 0
    val fraction = dragFraction ?: (positionMs.toFloat() / dur).coerceIn(0f, 1f)

    val amplitude by animateFloatAsState(
        targetValue = if (isPlaying && dragFraction == null) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessLow), label = "amplitude",
    )
    val phase by rememberInfiniteTransition(label = "wave").animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "phase",
    )
    val thumbHeight by animateDpAsState(if (dragFraction != null) 26.dp else 20.dp, label = "thumb")
    val active = MaterialTheme.colorScheme.primary
    val inactive = MaterialTheme.colorScheme.secondaryContainer

    Column(modifier) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(36.dp)
                .semantics {
                    contentDescription = "Song position"
                    progressBarRangeInfo = ProgressBarRangeInfo(fraction, 0f..1f)
                    setProgress { v -> onSeek((v.coerceIn(0f, 1f) * dur).toLong()); true }
                }
                .pointerInput(dur, enabled) {
                    if (!enabled) return@pointerInput
                    detectTapGestures { o -> onSeek(((o.x / size.width).coerceIn(0f, 1f) * dur).toLong()) }
                }
                .pointerInput(dur, enabled) {
                    if (!enabled) return@pointerInput
                    detectHorizontalDragGestures(
                        onDragStart = { o -> dragFraction = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = {
                            dragFraction?.let { onSeek((it * dur).toLong()) }
                            dragFraction = null
                        },
                        onDragCancel = { dragFraction = null },
                    ) { change, _ ->
                        change.consume()
                        dragFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
        ) {
            val stroke = 5.dp.toPx()
            val cy = size.height / 2
            val x = size.width * fraction
            val gap = 7.dp.toPx()
            val waveLength = 34.dp.toPx()
            val amp = 3.5.dp.toPx() * amplitude

            val playedEnd = x - gap
            if (playedEnd > 0f) {
                val path = Path()
                var px = 0f
                path.moveTo(0f, cy + amp * sin(-phase))
                while (px < playedEnd) {
                    px = (px + 2f).coerceAtMost(playedEnd)
                    path.lineTo(px, cy + amp * sin((2 * PI * px / waveLength).toFloat() - phase))
                }
                drawPath(path, active, style = Stroke(width = stroke, cap = StrokeCap.Round))
            }
            val restStart = x + gap
            if (restStart < size.width) {
                drawLine(inactive, Offset(restStart, cy), Offset(size.width, cy), stroke, StrokeCap.Round)
            }
            val tw = 5.dp.toPx()
            val th = thumbHeight.toPx()
            drawRoundRect(
                color = active,
                topLeft = Offset(x - tw / 2, cy - th / 2),
                size = Size(tw, th),
                cornerRadius = CornerRadius(tw / 2),
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp)) {
            val shown = dragFraction?.let { (it * dur).toLong() } ?: positionMs
            Text(formatDuration(shown), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(formatDuration(durationMs), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * Shape-morphing play button: a wide rounded square while paused, a circle while playing,
 * with a springy transition (Material 3 Expressive, as on Hello UI's Android 16 media player).
 */
@Composable
fun MorphPlayButton(isPlaying: Boolean, onClick: () -> Unit, height: Dp = 84.dp) {
    val corner by animateDpAsState(
        if (isPlaying) height / 2 else 26.dp,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow), label = "corner",
    )
    val width by animateDpAsState(
        if (isPlaying) height else height * 1.3f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow), label = "width",
    )
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(corner),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        modifier = Modifier.size(width, height),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                modifier = Modifier.size(42.dp),
            )
        }
    }
}

/** Grouped card list (Hello UI / Android 16 settings style): outer corners big, inner corners small. */
@Composable
fun CardGroup(modifier: Modifier = Modifier, content: CardGroupScope.() -> Unit) {
    val items = CardGroupScope().apply(content).items
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        items.forEachIndexed { i, item ->
            val big = 26.dp
            val small = 6.dp
            val shape = RoundedCornerShape(
                topStart = if (i == 0) big else small, topEnd = if (i == 0) big else small,
                bottomStart = if (i == items.lastIndex) big else small, bottomEnd = if (i == items.lastIndex) big else small,
            )
            val color = MaterialTheme.colorScheme.surfaceContainerHigh
            if (item.onClick != null) {
                Surface(onClick = item.onClick, shape = shape, color = color, modifier = Modifier.fillMaxWidth()) { item.content() }
            } else {
                Surface(shape = shape, color = color, modifier = Modifier.fillMaxWidth()) { item.content() }
            }
        }
    }
}

class CardGroupScope {
    internal class Item(val onClick: (() -> Unit)?, val content: @Composable () -> Unit)
    internal val items = mutableListOf<Item>()
    fun item(onClick: (() -> Unit)? = null, content: @Composable () -> Unit) { items += Item(onClick, content) }
}
