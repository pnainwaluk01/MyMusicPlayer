package com.mymusicplayer

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.glance.GlanceId
import androidx.glance.action.actionParametersOf
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.mymusicplayer.data.MusicFolderManager
import com.mymusicplayer.data.Song
import com.mymusicplayer.widget.Mix
import com.mymusicplayer.widget.MixKey
import com.mymusicplayer.widget.NextAction
import com.mymusicplayer.widget.PlayMixAction
import com.mymusicplayer.widget.PlayPauseAction
import com.mymusicplayer.widget.WidgetData
import com.mymusicplayer.widget.WidgetSync
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Runs on a real Android emulator in GitHub Actions. Creates three silent WAV files in the
 * music folder, plays them through the real player, and checks that what the widgets read
 * always matches what's actually playing, including commands sent from widget buttons.
 */
@RunWith(AndroidJUnit4::class)
class PlaybackWidgetSyncTest {

    private val context: Context = ApplicationProvider.getApplicationContext()
    private val container get() = (context.applicationContext as MusicApp).container
    private val files = mutableListOf<File>()
    private var scenario: ActivityScenario<MainActivity>? = null
    private val widgetId = object : GlanceId {}

    @Before
    fun setUp() {
        val ui = InstrumentationRegistry.getInstrumentation().uiAutomation
        val audio = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        ui.grantRuntimePermission(context.packageName, audio)
        if (Build.VERSION.SDK_INT >= 33) ui.grantRuntimePermission(context.packageName, Manifest.permission.POST_NOTIFICATIONS)

        val dir = MusicFolderManager().folder.apply { mkdirs() }
        listOf("Test_Song_A", "Test_Song_B", "Test_Song_C").forEach { name ->
            files += File(dir, "$name.wav").also { writeSilentWav(it, seconds = 40) }
        }
        scenario = ActivityScenario.launch(MainActivity::class.java)
    }

    @After
    fun tearDown() {
        runBlocking { onMain { container.player.stop() } }
        scenario?.close()
        files.forEach { it.delete() }
    }

    @Test
    fun widgetsFollowPlaybackFromAppAndWidgetButtons() = runBlocking {
        val songs = testSongs()
        assertEquals("all three test files should be found", 3, songs.size)
        assertEquals("underscores in untagged names are cleaned", "Test Song A", songs[0].title)

        // Played from the app
        onMain { container.player.playSongs(songs, 0) }
        var d = awaitWidget("song A playing") { it.current?.id == songs[0].mediaId && it.isPlaying }
        assertEquals(songs[0].title, d.current?.title)

        val versionBefore = WidgetSync.version.value
        onMain { container.player.next() }
        d = awaitWidget("song B playing after Next") { it.current?.id == songs[1].mediaId && it.isPlaying }
        assertEquals(songs[1].title, d.current?.title)
        assertTrue("open widgets are told to refresh", WidgetSync.version.value > versionBefore)
        assertTrue("song A shows in recently played", d.recent.any { it.id == songs[0].mediaId })

        onMain { container.player.togglePlayPause() }
        awaitWidget("paused on song B") { it.current?.id == songs[1].mediaId && !it.isPlaying }

        // Pressed on the widget itself
        PlayPauseAction().onAction(context, widgetId, actionParametersOf())
        awaitWidget("widget Play resumes song B") { it.current?.id == songs[1].mediaId && it.isPlaying }

        NextAction().onAction(context, widgetId, actionParametersOf())
        awaitWidget("widget Next goes to song C") { it.current?.id == songs[2].mediaId && it.isPlaying }

        PlayPauseAction().onAction(context, widgetId, actionParametersOf())
        awaitWidget("widget Pause") { it.current?.id == songs[2].mediaId && !it.isPlaying }

        PlayMixAction().onAction(context, widgetId, actionParametersOf(MixKey to Mix.SHUFFLE))
        d = awaitWidget("Quick mix Shuffle starts playback") { it.isPlaying }
        assertNotNull(songs.firstOrNull { it.mediaId == d.current?.id })

        // The widget shows exactly what the app's own player shows
        val appSong = onMain { container.player.state.value.currentSong?.mediaId }
        assertEquals(appSong, WidgetSync.load(context, 64, 4).current?.id)
    }

    private suspend fun testSongs(): List<Song> {
        repeat(5) {
            val lib = container.repository.scan(full = true)
            val found = lib.songs.filter { it.title.startsWith("Test Song") }.sortedBy { it.title }
            if (found.size == 3) return found
            delay(1_000)
        }
        return container.repository.library.value.songs.filter { it.title.startsWith("Test Song") }.sortedBy { it.title }
    }

    private suspend fun awaitWidget(what: String, check: (WidgetData) -> Boolean): WidgetData {
        var last = WidgetSync.load(context, 64, 4)
        val ok = withTimeoutOrNull(15_000) {
            while (!check(last)) {
                delay(200)
                last = WidgetSync.load(context, 64, 4)
            }
            last
        }
        return ok ?: throw AssertionError(
            "Widget never showed: $what. Last seen: song=${last.current?.title} id=${last.current?.id} playing=${last.isPlaying}",
        )
    }

    private suspend fun <T> onMain(block: () -> T): T = withContext(Dispatchers.Main) { block() }

    private fun writeSilentWav(file: File, seconds: Int) {
        val rate = 8000
        val dataLen = rate * 2 * seconds
        val b = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + dataLen); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(rate); b.putInt(rate * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen)
        file.writeBytes(b.array())
    }
}
